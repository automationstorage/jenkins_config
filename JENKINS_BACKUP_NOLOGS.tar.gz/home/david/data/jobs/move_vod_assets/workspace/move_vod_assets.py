#!/usr/bin/python2.7

#######################################################################

# IMPORTS

import urllib
import urllib2
import logging
import logging.handlers
from fxVegan import db_utils
import shelve
import signal
import sys
import os
import datetime
import time
import csv
import optparse
import configobj
import validate
import curses
import subprocess
try:
    import xml.etree.ElementTree as ET
except:
    import cElementTree as ET

#######################################################################

# Queries

CM_FILES_QUERY = """SELECT file_name, file_size
                    FROM cm_file
                    WHERE file_name like '%s' OR file_name like '%s'"""

CHECK_COPY_QUERY = "SELECT file_size FROM cm_file WHERE file_name = '%s'"

ASSET_DISTRIBUTION_STATMENT = "UPDATE asset_distribution SET edge_id = %s WHERE asset_id = %s"

VOLUME_NAME_QUERY = "SELECT value FROM edge_vod_volumes WHERE top_id = %s"


#######################################################################

LOG_PATH = 'move_vod_assets.log'
CONF_PATH = 'move_vod_assets.ini'
CONFIGSPEC_PATH = 'move_vod_assets.configspec.ini'

COPY_SERVICE = "FX_PVFS_File_Test/PVFS_Copy_File"
TEST_CLIENT_PORT = 1925
CLUSTER_PORT = 5929

logger = logging.getLogger("move_vod_assets")

ASSETS_OUTPUT_FIELDS = ["Asset ID", "Status", "Size"]
INPUT_HEADERS = ['data_id']


#######################################################################

# STATUSES

PROCESSING_STATUS = "processing"
START_COPY_STATUS = "started copying file"
COPY_FAILED_INITIATING_STATUS = "file copy failed on initiating"
COPY_SUCCESS_STATUS = "file copy succeeded"
COPY_FAILED_FILE_STATUS = "file copy failed"
COPY_DB_STATUS = "copying db info"
SUCCESS_STATUS = "copying success"
COPY_FAILED_STATUS = "copying failed"
READ_PICKLE_FAILED_STATUS = "failed to find data_id in pickle"
DONE_STATUS = "finished with asset"
USER_STOPPED_STATUS = "user stopped asset"

IGNORE_STATUS = [DONE_STATUS, SUCCESS_STATUS, COPY_FAILED_FILE_STATUS,
                 COPY_FAILED_STATUS, READ_PICKLE_FAILED_STATUS,
                 USER_STOPPED_STATUS, START_COPY_STATUS]


#######################################################################


class Asset(object):

    def __init__(self, data_id, old_volume, cluster_ip, status, timeout, block_ipg, block_size, db_con, new_volume, new_edge_id, time_to_sleep):
        self.data_id = str(data_id)
        self.cluster_ip = cluster_ip
        self.old_volume = old_volume
        self.new_volume = new_volume
        self.new_edge_id = new_edge_id
        self.status = status
        self.block_ipg = block_ipg
        self.block_size = block_size
        self.time_to_sleep = time_to_sleep
        self.timeout = timeout
        self.db_con = db_con
        self.get_asset_files()
        self.copied = False
        self.last_copy_check_time = None


    def get_asset_files(self):
        """
        Get all the asset files from cm_files
        """
        self.asset_files = []
        self.total_size = 0
        query_file_names = ('%s/%s.%s' % (self.old_volume, self.data_id, '%'), '%s/%s-%s' % (self.old_volume, self.data_id, '%'))
        query = CM_FILES_QUERY % query_file_names
        logger.debug("Get asset files - Executing query: %s", query)
        for row in self.db_con.execute(query):
                        self.asset_files.append(AssetFile(row.FILE_NAME, self.new_volume, row.FILE_SIZE, self.cluster_ip, self.block_ipg, self.block_size, self.db_con))
                        self.total_size += row.FILE_SIZE
        self.asset_files_iter = iter(self.asset_files)
    
        
    def copy_asset_file(self, streamer):
        """
        Copies one of the asset's files
        """
        try:
            asset_file = self.asset_files_iter.next()
            asset_file.copy_file(streamer)
            logger.info("started copying %s", self.data_id)
            self.status[self.data_id] = START_COPY_STATUS
        except FailedCopy:
            logger.warn("{} : {}".format(self.data_id, COPY_FAILED_INITIATING_STATUS))
            self.status[self.data_id] = COPY_FAILED_INITIATING_STATUS
            raise
        except StopIteration:
            raise


    def check_files_copy(self):
        """
        Check that all the files where copied properly
        """
        if not self.last_copy_check_time or time.time() - self.last_copy_check_time >= int(self.time_to_sleep):
            logger.debug("checking copy for asset %s", self.data_id)
            self.last_copy_check_time = time.time()
            for asset_file in self.asset_files:
                logger.debug("checking %s", asset_file.file_name)
                # If the asset wasn't already identifed as copied
                if not asset_file.copied:
                    logger.debug("file %s wasn't copied already", asset_file.file_name)
                    # Check if the file started the copy
                    if not asset_file.copy_time:
                        return False
                    # Check if the file finished the copy
                    asset_file.check_copy()
                    # Check if the file reaached timeout
                    if time.time() - asset_file.copy_time >= int(self.timeout) and not asset_file.copied:
                        logger.warn("Failed to copy asset %s due to timeout" % self.data_id)
                        self.status[self.data_id] = COPY_FAILED_FILE_STATUS
                        for f in self.asset_files:
                            if f.copy_time and not f.copied and f.streamer:
                                f.streamer.assets_num -= 1
                        raise FailedCopy()
                    logger.debug("copy status file %s: %s", asset_file.file_name, asset_file.copied)
                    if not asset_file.copied:
                        return False
            self.copied = True
            self.status[self.data_id] = COPY_SUCCESS_STATUS
            return True
        else:
            return self.copied

    def update_asset_distribution(self):
        """
        Update edge_id in asset_distribution table
        """
        query = ASSET_DISTRIBUTION_STATMENT % (self.new_edge_id, self.data_id)
        logger.debug("Update asset distribution - Executing query: %s", query)
        cur = self.db_con.execute(query)
        self.db_con.conn.commit()
        self.status[self.data_id] = DONE_STATUS

class AssetFile(object):

    def __init__(self, full_file_name, new_volume, file_size, cluster_ip, block_ipg, block_size, db_con):
        self.full_file_name = full_file_name
        self.old_volume, self.file_name = self.full_file_name.split("/")
        self.file_size = file_size
        self.new_volume = new_volume
        self.cluster_ip = cluster_ip
        self.block_ipg = block_ipg
        self.block_size = block_size
        self.db_con = db_con
        self.copy_time = None
        self.copied = False
        self.copied_size = 0
        self.streamer = None
       
    def copy_file(self, streamer):
        """
        Copy the file using %s service
        """ % COPY_SERVICE
        self.streamer = streamer
        logger.info("started copying file: %s", self.file_name)
        info = {
                    "file_path" : self.file_name,
                    "volume_name" : self.old_volume,
                    "cluster_name" : self.cluster_ip,
                    "cluster_port" : 1928,
                    "use_src_fabrix_fs" : 1,
                    "dst_cluster_name" : self.cluster_ip,
                    "dst_cluster_port" : 1928,
                    "dst_volume" : self.new_volume,
                    "dst_file" : self.file_name,
                    "use_dst_fabrix_fs" : 1,
                    "block_size" : self.block_size,
                    "block_ipg" : self.block_ipg,
                    "is_block_size_rand" : 0,
                    "get_all_bytes" : 0,
                    "file_flag" : 1,
                    "file_flag_help" : 'W(1),X(3),A(5)',
                    "has_data_inode" : 0
                   }
        url = "http://%s:%d/%s?%s" % (self.streamer.node_ip, TEST_CLIENT_PORT, COPY_SERVICE, urllib.urlencode(info))

        logger.debug(url)
        
        response = self.streamer.send_request_to_streamer(url)
        if response is None or response.find("<status>success</status>") == -1:
            logger.warn(response)
            raise FailedCopy()
        self.copy_time = time.time()

    def check_copy(self):
        """
        Check that the file was copied propely
        """
        query_file_name  = os.path.join(self.new_volume, self.file_name)
        res = self.db_con.execute(CHECK_COPY_QUERY % query_file_name).fetchall()
        if len(res) > 0:
            if res[0].FILE_SIZE == self.file_size:
                self.copied = True
                logger.debug("Finished copying %s", self.file_name)
                self.streamer.assets_num -= 1
                return
            if self.copied_size > 0 and res[0].FILE_SIZE == self.copied_size:
                logger.warn("Size of %s remained the same since last check (%d)",
                            self.file_name, self.copied_size)
            self.copied_size = res[0].FILE_SIZE


class Streamer(object):
    def __init__(self, node_ip, node_name):
        self.node_ip = node_ip
        self.assets_num = 0
        self.node_name = node_name

    def is_active(self):        
        """
        Checks if the streamer is active
        """
        proc = subprocess.Popen(["sysu", "-N", self.node_name, "psh", "hostname"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logger.warn("Checking if is active %s", self.node_name)        
        output = proc.communicate()
        if output[0].find("Execution failed: No route to host") != -1:
            logger.warn("can't connect to %s", self.node_name)
            return False
        return True

    def send_request_to_streamer(self, url_request):
        """
        Send a url request to the node
        """
        logger.debug("sending request %s", self.node_ip)
        return send_url(url_request)
        

class Queue(object):
    def __init__(self, concurrent_files, data_ids_list, cluster_ip, status_keeper,
                 timeout, block_ipg, block_size, db_con, assets_output, src_edge,
                 dst_edge, time_to_sleep):
        self.concurrent_files = concurrent_files
        self.data_ids_list = data_ids_list
        self.data_ids_list_iter = iter(self.data_ids_list)
        self.cluster_ip = cluster_ip
        self.status = status_keeper
        self.timeout = timeout
        self.block_ipg = block_ipg
        self.block_size = block_size
        self.db_con = db_con
        self.assets_output = assets_output
        self.src_edge = src_edge
        self.dst_edge = dst_edge
        self.time_to_sleep = time_to_sleep
        self.src_volume = get_volume(self.db_con, self.src_edge)
        self.dst_volume = get_volume(self.db_con, self.dst_edge)
        self.create_streamers_queue(self.src_edge)
        self.cur_asset = None
        self.assets_queue = {}


    def _get_topology(self):
        """
        Gets the topology xml
        """
        topo_xml = send_url("http://127.0.0.1:5929/topology_get_regions?X=0") # assuming the script runs from the manager
        if topo_xml:
            return topo_xml
        else:
            logger.warn("Couldn't get topology...")
            raise ReadTopologyError()


    def create_streamers_queue(self, pod):
        """
        Extract region id, edge id and create a list of streamer objects from the topology xml (only relevant pod)
        """
        logger.debug("Creating streamers queue...")
        self.streamers_queue = []
        xml = self._get_topology()
        try:
            tree = ET.fromstring(xml)
        except Exception, e:
            logger.exception(e)
            raise ReadTopologyError()
        edges = tree.findall('regions/elem/edges/elem')
        # Check given pod
        edge = None
        # Trying to extract relevant pod
        for optional_edge in edges:
            # Using find and not just comparing in case the pod name is with spaces
            if optional_edge.find("id").text.find(pod) > -1:
                edge = optional_edge
        # If failed to find pod, exit
        if not edge:
            logger.warn("Can't find requested pod!")
            raise ReadTopologyError()
        # Extract streamers for requested pod
        for node in edge.findall('streamers/elem'):
            streamer = Streamer(node.find("addr").text.split(':')[0],(node.find("name").text))
            if streamer.is_active():
                self.streamers_queue.append(streamer)                  

    def fill_queue(self):
        """
        Sends copy requests until the number of files reaches the limit
        """
        if not self.cur_asset:
            try:
                self.get_asset()
            except StopIteration:
                # No assets left
                return

        while sum([streamer.assets_num for streamer in self.streamers_queue]) < int(self.concurrent_files):
            streamer = self.get_free_streamer()
            try:
                # Copy an asset file and add the asset to the queue
                self.cur_asset.copy_asset_file(streamer)
                streamer.assets_num += 1
                self.assets_queue[self.cur_asset.data_id] = self.cur_asset
            except StopIteration:
                # All the asset's files had been sent to copy
                try:
                    self.get_asset()
                    continue
                except StopIteration:
                    # No assets left
                    break
                
    def get_asset(self):
        """
        Gets the next data_id and creates an Asset object
        """
        if should_stop:
            raise StopIteration
        for data_id in self.data_ids_list_iter:
            if not self.status.has_key(str(data_id)) or self.status[str(data_id)] not in IGNORE_STATUS:
                # It is safer to restart than to resume
                self.status[str(data_id)] = PROCESSING_STATUS
            else:
                logger.debug("skipped asset %s because it's in ignore_status list: %s", data_id, self.status[str(data_id)])
                continue
            self.cur_asset = Asset(data_id, self.src_volume, self.cluster_ip,
                            self.status, self.timeout, self.block_ipg, self.block_size,
                            self.db_con, self.dst_volume, self.dst_edge, self.time_to_sleep)
            return
        raise StopIteration
        
    def get_free_streamer(self):
        """
        Gets the streamer that is doing the least number of copys at the time
        """
        return sorted([(i.assets_num,i) for i in self.streamers_queue])[0][1]

    def remove_from_queue(self, asset):
        """
        Remove asset from queue and fill it again
        """
        self.assets_queue.pop(asset.data_id)
        logger.info("Removed data_id : %s from queue", asset.data_id)
        self.assets_output.writerow({'Asset ID' : asset.data_id,
                                     'Status' : self.status[asset.data_id],
                                     'Size' : str(asset.total_size)})
        self.fill_queue()

    def run(self):
        """
        Handle the assets according to their status (including removing them from the queue)
        """
        status_function_dict = {START_COPY_STATUS : Asset.check_files_copy
                               ,COPY_SUCCESS_STATUS : Asset.update_asset_distribution
                               ,DONE_STATUS : self.remove_from_queue
                               ,USER_STOPPED_STATUS : self.remove_from_queue}
        self.fill_queue()
        # Syncing the status db before every loop
        self.status.sync()
        if self.assets_queue:
            for data_id, asset in self.assets_queue.items():
                asset_status = self.status[data_id]
                try:
                    status_function_dict[asset_status](asset)
                except FailedCopy, e:
                    logger.info("asset %s failed [%s]", data_id,
                                self.status[data_id])
                    self.remove_from_queue(asset)
            return True
        return False
          


class StatusKeeper(object):
    def __init__(self, status_file):
        self.status_file = status_file
        self.max_output_size = 0
        #self.stdscr = curses.initscr()
               

    def update_status(self):
        """
        Update the status according to status file
        """
        self.counter = {}
        for value in self.status_file.values():
            if self.counter.has_key(value):
                self.counter[value] += 1
            else:
                self.counter[value] = 1

    def export_status_final(self):
        """
        Write the status to log and print it
        """
        self.close()
        self.update_status()
        for status, count in self.counter.items():
            status_str = "STATUS: %s : %s" % (status, count)
            logger.info(status_str)
            print status_str

    def export_status_stdout(self):
        """
        Write the status to stdout
        """
        self.stdscr.clear()
        self.update_status()
        self.stdscr.addstr(0, 0, "Number of assets to copy : %d" % len(self.status_file), curses.A_BOLD)
        n = 1
        for status, count in self.counter.items():
            self.stdscr.addstr(n, 0, "%s: %s" % (status, count))
            n += 1
        self.stdscr.refresh()
        

    def close(self):
        """
        Close stdscr
        """
        #curses.endwin()

    def __getitem__(self, key):
        return self.status_file[key]

    def has_key(self, key):
        return self.status_file.has_key(key)

    def __setitem__(self, key, val):
        self.status_file[key] = val

    def sync(self):
        self.status_file.sync()
        #self.export_status_stdout()


class FailedCopy(Exception):
    def __init__(self, file_name=None):
        self.file_name = file_name
    def __str__(self):
        return repr('Failed to copy file %s' % self.file_name)

class PickleError(Exception):
    def __init__(self, fname, message):
        Exception.__init__(self, message)
        self.fname = fname

class ReadTopologyError(Exception):
    def __str__(self):
        return repr('Failed to get topology')


def get_volume(db_con, edge_id):
    """
    Gets a db_con and returns volume name and the edge_id (assuming there is only one pod)
    """
    res = db_con.execute(VOLUME_NAME_QUERY % edge_id).fetchone()
    volume_name = res.VALUE
    return volume_name


def read_conf():
        """
        Read and validate configuration file
        """
        logger.debug("Try to read validate configuration file")
        validator = validate.Validator({'validate_file_exists': validate_file_exists})
        try:
            conf = configobj.ConfigObj(CONF_PATH, file_error=True, configspec=CONFIGSPEC_PATH)
            res = conf.validate(validator)
            if not res:
               raise validate.ValidateError()
            res_flat = configobj.flatten_errors(conf, res)
            if res_flat:
                err_str = ''
                for i in res_flat:
                    err_str += 'section: %s field: %s error: %s\n' % i
                raise validate.ValidateError(err_str)
        except (configobj.ConfigObjError, IOError), e:
            logger.critical("Could not read %s", CONF_PATH)
            logger.exception(e)
            sys.exit(1)
        except validate.ValidateError, e:
            logger.critical("Could not validate one of the fields")
            logger.exception(e)
            sys.exit(1)
        return conf


def send_url(url, xml=None):
    """
    Creates a url request and sends it
    """
    logger.debug("Sending request {}".format(url))
    if xml:
        req = urllib2.Request(url=url, data=xml, headers={"Content-Type": "text/xml"})
    else:
        req = urllib2.Request(url=url)
    try:
        response = urllib2.urlopen(req).read()
    except urllib2.HTTPError, e:
        logger.error("Problem sending request: {}, reason {}".format(url, e))
        return None
    except urllib2.URLError, e:
        logger.error("Problem sending request: {}, reason {}".format(url, e.reason))
        return None
    logger.debug("Got response {}".format(response))
    return response


# Conf validation functions
def validate_file_exists(path):
    """
    Make sure that the file exists
    """
    if not os.path.exists(path):
        raise validate.ValidateError("File %s doesn't exist!" % path)
    return path


# Signal handling functions
def stop_script(signum, frame):
    logger.info("Got signal %d, stop adding assets to the queue", signum)
    global should_stop
    should_stop = True

def resume_script(signum, frame):
    logger.info("resuming script")

def fail_assets(signum, frame):
    logger.info("Got signal %d, change running assets to failed status", signum)
    global stop_timeout
    stop_timeout = True


def main():
    print "Started running! pid:", os.getpid()
    global should_stop, stop_timeout
    should_stop = False
    stop_timeout = False
    # Setup signal handlers
    signal.signal(signal.SIGUSR1, stop_script)
    signal.signal(signal.SIGCONT, resume_script)
    signal.signal(signal.SIGCHLD, signal.SIG_DFL)
    signal.signal(signal.SIGUSR2, fail_assets)

    # Parse command line
    parser = optparse.OptionParser("%prog [--debug]")
    parser.add_option("--debug", action="store_true", dest="debug", default=False, help="Use this option if you want debug in the log")
    (options, args) = parser.parse_args()

    
    # create log file
    formatter = logging.Formatter('%(process)d %(asctime)s %(levelname)s %(message)s')
    handler = logging.handlers.RotatingFileHandler(
              LOG_PATH, maxBytes=10*1024*1024, backupCount=5, mode="a")
    if options.debug:
        logger.setLevel(logging.DEBUG)
        handler.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)
        handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    conf = read_conf()
    open_stuff = []
    db_con = db_utils.SolidODBCConnection()
    logger.info("created db connection")

    # Checking if the assets output file already exists
    # We need to check it because in this file we write in append mode
    # (because we write an asset when the script is done with it)
    assets_output_path = conf['General']['assets_output_path']
    output_exists = False
    if os.path.exists(assets_output_path):
        output_exists = True
    assets_output = open(assets_output_path, "ab")
    open_stuff.append(assets_output)
    assets_output_csv = csv.DictWriter(assets_output, ASSETS_OUTPUT_FIELDS)
    if not output_exists:
        assets_output_csv.writer.writerow(ASSETS_OUTPUT_FIELDS)

    # Read status file
    try:
        status = shelve.open(conf['General']['status_pkl'], writeback=True)
        open_stuff.append(status)
        status_keeper = StatusKeeper(status)
        open_stuff.append(status_keeper)
    except Exception, e:
        raise PickleError(conf['General']['status_pkl'], str(e))

    # Read data ids from input csv file
    input_file = open(conf['General']['input_file'])
    input_csv = csv.DictReader(input_file, INPUT_HEADERS)
    input_csv.next() # skipping header line
    data_ids_list = [row['data_id'] for row in input_csv]
    input_file.close()
        
    # Copy assets
    try:
        queue = Queue(conf['General']['concurrent_files'], data_ids_list, 
                      conf['General']['cluster_ip'], status_keeper, 
              conf['General']['timeout'], conf['General']['block_ipg'], 
              conf['General']['block_size'], db_con, assets_output_csv,
                      conf['General']['src_pod'], conf['General']['dst_pod'],
                      conf['General']['time_to_sleep'])
        running = True
        while running:
            running = queue.run()
        logger.info("finished!")
        status_keeper.export_status_final()
    except Exception, e:
        logger.critical("There was an unexpected error")
        logger.exception(e)
    finally:
        # Closing connections and files
        for i in open_stuff:
            i.close()
    print "Done!"
    


if __name__ == "__main__":
    main()
