#!/usr/bin/python2.7

from fxVegan import db_utils
import datetime 
import time
import os
from optparse import OptionParser
import csv
import logging
import logging.handlers

# QUERIES
GET_ASSETS_QUERY = """SELECT data_id, external_id
                        FROM asset JOIN asset_distribution ON (data_id = asset_id)
                        WHERE active = 1 AND edge_id = %s AND ingesting = 0 AND data_type = 0
                        LIMIT %s OFFSET %s"""
						
						
OUTPUT_HEADERS = ['DATA_ID', 'EXTERNAL_ID']

LOG_PATH = "move_vod_assets_finder.log"
logger = logging.getLogger("move_vod_assets_finder")

class AssetFinder(object):
	def __init__(self, query_limit, output_path, edge_id):
		self.con = db_utils.SolidODBCConnection(dsn='solid_ha_read_mostly')
		self.limit = query_limit
		self.offset = 0
		self.edge_id = edge_id
		self.set_output_file(output_path)
	
	def set_output_file(self, output_path):
		self.output_file = csv.DictWriter(open(output_path, 'wb'), OUTPUT_HEADERS)
		self.output_file.writer.writerow(OUTPUT_HEADERS)
		
	def next(self):
		"""
                Getting the next chunk of assets
		"""
		query = GET_ASSETS_QUERY % (self.edge_id, self.limit, self.offset)
		logger.debug(query)
		cur = self.con.execute(query)
		self.assets = cur.fetchall()
		if not self.assets:
			raise StopIteration
		logger.info("fetched %d assets", len(self.assets))
		self.offset += self.limit
		self.export_chunk()
		
		
	def export_chunk(self):
		for asset in self.assets:
			asset_dict = {'DATA_ID' : asset.DATA_ID,
						  'EXTERNAL_ID' : asset.EXTERNAL_ID}
			self.output_file.writerow(asset_dict)
		
	def __iter__(self):
		return self
		
	
		
def verify_time_window(start_time, end_time):
        """
        Checks if 'now' is between start time and end time - if not, waits until it does
        """
        now = datetime.datetime.now()
        today_start_time = datetime.datetime.combine(datetime.datetime.today(), start_time)
        today_end_time = datetime.datetime.combine(datetime.datetime.today(), end_time)
        if now > today_start_time:
            if now < today_end_time or today_end_time <= today_start_time:
                    return
            else:
                    # tomorrow
                    sleep_time = time.mktime(today_start_time.timetuple()) - time.mktime(now.timetuple()) + 60 * 60 * 24
                    logger.info("not in time window - waiting %d seconds", sleep_time)
                    time.sleep(sleep_time)
                    return
        else:
            if now < today_end_time and today_end_time <= today_start_time:
                     return
            else:
            # today
                    sleep_time = time.mktime(today_start_time.timetuple()) - time.mktime(now.timetuple())
                    logger.info("not in time window - waiting %d seconds", sleep_time)
                    time.sleep(sleep_time)
                    return
		
		
def main():
        # Parse option
        parser = OptionParser("%prog <edge_id> -o <output_path> [-s <start_time>] [-e <end_time>] [-l <query_limit>] [-d <delay>] [--debug]")
        parser.add_option("-s", dest="start_time", default="00:00:00", 
                                                help="at what time to start running queries (every day) [default: %default]")
        parser.add_option("-e", dest="end_time", default="00:00:00", 
                                                help="at what time to stop running queries (every day) [default: %default]")
        parser.add_option("-o", dest="output_path", help="a csv file to write to")
        parser.add_option("-l", dest="query_limit", default=1000, type="int", 
                                                help="how many assets to fetch in each iteration [default: %default]")
        parser.add_option("-d", dest="delay", type="int", default=0, 
                                                help="how many seconds to wait between each query [default: %default]")
        parser.add_option("--debug", dest="debug", action="store_true", default=False,
                                                help="run the script in debug mode")
	
        options, args = parser.parse_args()
        if len(args) != 1 or not options.output_path:
            parser.error("missing edge_id or output_file")

        # create log file
        formatter = logging.Formatter('%(process)d %(asctime)s %(levelname)s %(message)s')
        handler = logging.handlers.RotatingFileHandler(LOG_PATH, maxBytes=10*1024*1024, backupCount=5, mode="a")
        if options.debug:
                logger.setLevel(logging.DEBUG)
                handler.setLevel(logging.DEBUG)
        else:
                logger.setLevel(logging.INFO)
                handler.setLevel(logging.INFO)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        try:
                start_time = datetime.datetime(*(time.strptime(options.start_time, "%H:%M:%S")[0:6])).time()
                end_time = datetime.datetime(*(time.strptime(options.end_time, "%H:%M:%S")[0:6])).time()
        except ValueError:
                parser.error("Bad time format!")
	
        verify_time_window(start_time, end_time)

        assets_finder = AssetFinder(options.query_limit, options.output_path, args[0])
        for assets_chunk in assets_finder:
                verify_time_window(start_time, end_time)
                time.sleep(options.delay)
                
        logger.info("done!")
        print "done!"

if __name__ == '__main__':
	main()
