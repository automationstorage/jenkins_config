VERSION="1.0"
DESCRIPTION="The script copys vod assets from one pod to another"
NAME="move_vod_assets"

if [ "${BUILD_NUMBER}X" = "X" ] ; then
    exit 1
fi

echo "Removing unnecessary files"
find . -name .svn | xargs rm -rf
find . -name "test*" | xargs rm -rf

echo "Fixing permissions"
chmod 755 *.py
chmod 644 Util/scripts/move_vod_assets/*.ini

fpm -s dir -t rpm -n ${NAME} --description "${DESCRIPTION}" -v ${VERSION} \
 --iteration ${BUILD_NUMBER} -a noarch --depends fxVegan \
 --config-files /opt/Fabrix.TV/Util/scripts/move_vod_assets/move_vod_assets.ini \
 --prefix /opt/Fabrix.TV/Util/scripts/move_vod_assets \
 move_vod_assets.py move_vod_assets_finder.py move_vod_assets.ini move_vod_assets.configspec.ini
