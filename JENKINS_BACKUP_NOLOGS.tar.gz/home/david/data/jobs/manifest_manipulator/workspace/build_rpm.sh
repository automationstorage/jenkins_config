VERSION="1.0"
DESCRIPTION="Manipulate manifest for replacing the ad-breaks."
NAME="manifest_manipulator_service"

if [ "${BUILD_NUMBER}X" = "X" ] ; then
    exit 1
fi

echo "Removing unnecessary files"
find . -name .svn | xargs rm -rf

echo "Creating directory tree"
mkdir -p etc/service_server.d
mkdir -p etc/service_server/modules.d/manifest_manipulator/
mkdir -p opt/Fabrix.TV/logs
chmod 755 etc/service_server.d etc/service_server/modules.d opt/Fabrix.TV/logs

echo "Moving files"
cp -R m3u8_POC etc/service_server/modules.d/manifest_manipulator/m3u8_POC
cp -R iso8601 etc/service_server/modules.d/manifest_manipulator/iso8601
cp *.py *.ini etc/service_server/modules.d/manifest_manipulator/
cp *.conf etc/service_server.d/

echo "Fixing permissions"
chmod 755 etc/service_server/modules.d/manifest_manipulator/*.py
chmod 664 etc/service_server/modules.d/manifest_manipulator/*.ini etc/service_server.d/*.conf

echo "Creating RPM"
fpm -s dir -t rpm -n ${NAME} --description "${DESCRIPTION}" -v ${VERSION} \
 --iteration ${BUILD_NUMBER} -a noarch \
 --depends "service_server => 1.2" --depends "fxVegan => 1.8.3" \
 --config-files etc/service_server/modules.d/manifest_manipulator/manifest_manipulator.ini \
 etc opt