#! /usr/bin/env python2.7
"""
Manipulating HLS manifests.
"""
import urlparse
import ManifestManipulator as MP
import logging
import sys
from fxVegan import config_utils
from fxVegan import log_utils
from datetime import datetime, timedelta

######################
#### Const Params ####
######################

INI_CONFIG_FILE = '/etc/service_server/modules.d/manifest_manipulator/manifest_manipulator.ini'
MAX_TIME_TO_REMOVE_SESSION = 120 #second

###################################
#### Global and Default Params ####
###################################

# The following part meant to set globals only
# if they didn't sets already at previous loading.
# This issue solve the part of sending different registarts
# to the same python module, using service_server. 

thismodule = sys.modules[__name__] 
def set_global(glo,val):
    if glo not in globals():
        setattr(thismodule, glo, val)

# script params
manipulators={}
set_global('last_clean_time', datetime.now())
set_global('loaded_setup', False)
set_global('logger', None)
#[General]
set_global('streamer_ip','10.10.39.60')
set_global('streamer_port','5555')
#[Manifest]
set_global('full_path_segments',False)
#[Simulator]
set_global('simulator_ip','10.10.39.60')
set_global('simulator_port','9876')
#[Log]
set_global('log_path','/opt/Fabrix.TV/logs/manipulate_manifest_service.log')
set_global('log_size','5MB')
set_global('rotations',3)
set_global('verbosity',1)
set_global('extension_ops', ['.m3u8'])
set_global('zone_dict', {})
  
##############################
###### Initial  Service ######  
##############################

def load_setup():
    """
    This function setup the service before it is 
    started  to get requests
    """
    global log_path
    global log_size
    global rotations
    global logger
    global loaded_setup
    global verbosity
    # const path for conf file.
    if not loaded_setup:
        parse_configuration(INI_CONFIG_FILE)
        log_utils.set_rot_file_log(log_path,
            fmt='%(asctime)s\t%(name)s\t%(levelname)s\t%(message)s',
            size=log_size,
            backups=rotations)
        #logging.debug is 10, info is 20 and etc..
        logger = logging.getLogger("manifest_manipulator")
        logger.setLevel(verbosity*10)
        loaded_setup = True

def parse_configuration(path):
    """
    This function parse the config file. It there are missing parameters
    in the config file, this function puts the default class parameters.
    :param config: path for config file, default is config path of the class.
    :type config: str
    """
    #[General]
    global streamer_ip
    global streamer_port
    #[Manifest]
    global full_path_segments
    #[Simulator]
    global simulator_ip
    global simulator_port
    #[Log]
    global log_path
    global log_size
    global rotations
    global verbosity
    global zone_dict

    default_sections = ["Log","General","Manifest" "Simulator"]
    default_values = {
                    "streamer_ip" : streamer_ip,
                    "streamer_port" : streamer_port,
                    #"fregment_length" : str(fregment_length),
                    #"extension" : extension,
                    #"device_profile" : device_profile,
                    "full_path_segments" : str(full_path_segments),
                    "simulator_ip" : simulator_ip,
                    "simulator_port" : str(simulator_port),
                    "path" : log_path,
                    "size" : log_size,
                    "rotations": str(rotations),
                    "verbosity" : str(verbosity)
                    }

    conf = config_utils.get_config(path,
                    default_sections=default_sections,
                    default_values=default_values)

    ## update params ##
    #[General]
    streamer_ip=conf.get("General", "streamer_ip")
    streamer_port=conf.get("General", "streamer_port")
    #[Manifest]
    #fregment_length=conf.getint("Manifest", "fregment_length")
    #extension=conf.get("Manifest","extension")
    #device_profile=conf.get("Manifest","device_profile")
    full_path_segments=conf.getboolean("Manifest", "full_path_segments")
    #[Simulator]
    simulator_ip = conf.get("Simulator","simulator_ip")
    simulator_port = conf.getint("Simulator","simulator_port")
    #[Log]
    log_path=conf.get("Log", "path")
    log_size=conf.getsize("Log", "size")
    rotations=conf.getint("Log", "rotations")
    verbosity=conf.getint("Log", "verbosity")

    #get zoens
    if conf.has_section("Zones"):
        zones = conf.options("Zones")
        for z in zones:
            if z not in default_values:
                zone_dict[z.upper()] = conf.get("Zones",z)


def manipulators_cleaner():
    global manipulators
    global logger
    global last_clean_time

    #cleaning every MAX_TIME_TO_REMOVE_SESSION seconds.
    if (datetime.now() - last_clean_time).total_seconds() >= MAX_TIME_TO_REMOVE_SESSION:
        key_for_removing = []
        logger.debug("Cleaning manipulators...")
        for key, val in manipulators.items():
            # check time diff
            diff = (datetime.now() - val[1]).total_seconds()
            if diff > MAX_TIME_TO_REMOVE_SESSION:
                key_for_removing.append(key)
        for key in key_for_removing:
            logger.info("Removing objects of {0}".format(key))
            val = manipulators.pop(key)
            del val # no left pointers to this value
        last_clean_time = datetime.now()

# ugly fest function for calculate if ip belongs to a net
def addressInNetwork(ip, net):
    ipaddr = int(''.join([ '%02x' % int(x) for x in ip.split('.') ]), 16)
    netstr, bits = net.split('/')
    netaddr = int(''.join([ '%02x' % int(x) for x in netstr.split('.') ]), 16)
    mask = (0xffffffff << (32 - int(bits))) & 0xffffffff
    return (ipaddr & mask) == (netaddr & mask)

def get_zone(ip):
    global zone_dict
    global logger
    for z,net in zone_dict.items():
        if addressInNetwork(ip, net):
            logger.debug("Connecting %s to zone %s"%(ip,z))
            return z
    return ''


#######################
###### Executers ######
#######################

def is_variant_manifest_req(path):
    """
    Returns if the url request is a request for variant manifest
    """
    #http://10.10.39.60:5555/shls/LIVE$ad/5.m3u8?start=LIVE&end=END&device=HLS
    global extension_ops
    url = urlparse.urlparse(path)
    for ext in extension_ops:
        if url.path[-len(ext):] == ext:
            return True
    return False

def is_level_manifest_req(path):
    """
    Returns if the url request is a request for level manifest
    """
    url = urlparse.urlparse(path)
    if '/Level' in url.path: #### check the performance of this line ###########
        return True
    return False 

def clean_manipulators():
    global manipulators
    global loggers


def execute(handler):
    """
    Gets requests.
    :param handler: A request handler given from the service server
    :return: output dictionary
    """
    global logger
    global manipulators
    global streamer_ip
    global streamer_port
    global simulator_ip
    global simulator_port
    global full_path_segments

    logger.info("Handling request {request} from {client}".format(request=handler.path,
                                                                client=handler.client_address))

    # takes into consideration only the ip of the client. 
    # cannot play from one client twice at the same time. 
    ip_addr = handler.client_address[0]
    if not manipulators.get(ip_addr,None):
        logger.debug("Creates an manipulate object for IP %s"%ip_addr)
        zone = get_zone(ip_addr)
        if not zone:
            msg = "IP address doesn't belong to any zone"
            logger.error(msg)
            return {"succeeded" : False, "message" : msg}
        manipulators[ip_addr] = [MP.ManifestManipulator(streamer_ip, streamer_port, simulator_ip, simulator_port,
                                        full_path_segments, zone), datetime.now()]
    else:
        manipulators[ip_addr][1] = datetime.now()

    if is_level_manifest_req(handler.path):
        output = manipulators[ip_addr][0].handle_level_manifest_req(handler.path)
    elif is_variant_manifest_req(handler.path):
        output = manipulators[ip_addr][0].handle_variant_manifest_req(handler.path)
    else:
        output = manipulators[ip_addr][0].handle_streamer_proxy_req(handler.path)
    
    for key,value in output.items():
        logger.debug("Sending output- {0}: {1} ".format(key,value))
    manipulators_cleaner()
    return output

def execute2(handler):
    """
    Post requests.
    """
    pass
