#! /usr/bin/python

# IP and port to listen to
LISTEN_IP = ""
LISTEN_PORT = 9876

# The list of actions to do. Each item corresponds to a splice point.
# Every item in the splice point list is an action.
# Every action is a tuple of the action name and its parameters:
#   ('fixed', time_in_seconds) - do nothing
#   ('fill', external_id, time_in_seconds) - insert ad
#   ('replace', external_id, time_in_seconds) - replace with ad
#   ('delete', external_id) - delete the content
#
# If there are more splice points, the actions will restart (meaning if there
# are n actions and m splice points and m>n, then splice point n+1 will get
# action 1, splice point n+2 will get action 2, etc.)
#ACTIONS = [ \
#            [ \
#              ('replace', '1293526254621', 30), \
#            ], \
#            [ \
#              ('replace', '1293526174942', 30) \
#            ] \
#          ]

#ACTIONS = [[('replace', 'WebUI-1440507751478', 10)]]
ACTIONS = [[('replace', 'ads1', 10)],
		   [('replace', 'ads2', 10)],
		   [('replace', 'ads3', 10)],
		   [('replace', 'ads4', 10)]]

# --- NEW ---
ACTIONS_DICT = {"MAC1" : [[('replace', 'ADS1', 10)],
						   [('replace', 'ADS2', 10)],
						   [('replace', 'ADS3', 10)],
						   [('replace', 'ADS4', 10)],
						   [('replace', 'ADS5', 10)],
						   [('replace', 'ADS6', 10)]],

				"MAC2" : [[('replace', 'ADS7', 10)],
						   [('replace', 'ADS8', 10)],
						   [('replace', 'ADS9', 10)],
						   [('replace', 'ADS10', 10)],
						   [('replace', 'ADS11', 10)],
						   [('replace', 'ADS12', 10)]]
				}
#ACTIONS = [[('replace', '1311839489870', 30),('replace', '1311839489870', 30)]]

# The following variable can get any of these values:
# 1 - Insert junk in the PlacementResponse
# 2 - Duplicate each PlacementResponse in the connection
TESTING = 0

# The following is a list of event IDs that the simulator should not recognize
UNKNOWN_EVENT_IDS = []

# 0 - For every PlacementRequest, start the actions from the beginning
# 1 - Cyclicly run through the actions, starting in the next PlacementRequest from where we stopped in the prior PlacementRequest
# 2 - Randomly choose an action for each PlacementRequest
# --- NEW --- use 2 for randomally choose according to ad zone.
ACTIONS_MODE = 2

# Debug level of prints
# 0 - No debugging prints
# 1 - Basic debugging prints
# 2 - Performance debugging prints
DEBUG_LEVEL=1

# Whether to use SOAP headers
USE_SOAP=False


import libxml2
import socket
import sys
import time
import random

random.seed ()

cyclicIndex = -1
trackId = 0

class Timer:
	def startTimer(self):
		self._startTime = time.time ()
	def stopTimer(self, printStr, minTimeToPrint = 0):
		if self._startTime != 0:
			totalTime = time.time() - self._startTime
			if totalTime > minTimeToPrint:
				print printStr, totalTime
			self._startTime = 0

def getChildElems(elem, name = None):
	children = []
	childElem = elem.get_children()
	while childElem != None:
		if childElem.type == 'element':
			if name == None or childElem.name == name:
				children.append (childElem)
		childElem = childElem.get_next()
	return children

def getText(elem):
	return d.getContent().strip()

def getAttr(elem, attrName):
	return elem.prop(attrName)

def createErrorResponseHeader(err):
	return "HTTP/1.1 500 Internal Server Error\nServer: gSOAP/2.7\nContent-Type: text/xml; charset=utf-8\nContent-Length: " + str(len(err)) + "\nConnection: close\n\n"

def createErrorResponse(elementName):
	err = '<?xml version="1.0" encoding="UTF-8"?>\n<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" xmlns:ads="http://www.scte.org/wsdl/130-3/2009/ads" xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm"><SOAP-ENV:Body><SOAP-ENV:Fault><faultcode>SOAP-ENV:Client</faultcode><faultstring>Validation constraint violation: tag name or namespace mismatch in element "' + elementName + '"</faultstring></SOAP-ENV:Fault></SOAP-ENV:Body></SOAP-ENV:Envelope>'
	return createErrorResponseHeader(err) + err

def attachSuccessHeaders(successXml):
	completeMessage = ""
	if USE_SOAP:
		completeMessage =  "HTTP/1.0 200 OK\nServer: Python Server\nContent-Length: " + str(len(successXml)) + "\nContent-Type: text/xml\nDate: Tue, 26 May 2009 11:12:05 GMT\nPragma: no-cache\nConnection: close\n\n" + successXml
	else:
		length = len(successXml)
		lengthStr = ""
		while len(lengthStr) < 4:
			lengthStr = chr(length % 256) + lengthStr
			length /= 256
		completeMessage = "\x00\x00\x00\x01" + lengthStr + successXml
	return completeMessage

def createSuccessResponse(placementDecisions, messageId, statusCodeClass, statusCodeDetail, statusCodeNote):
	responseXml = '<?xml version="1.0" encoding="UTF-8"?>\n'
	if USE_SOAP:
		responseXml += '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" xmlns:ads="http://www.scte.org/wsdl/130-3/2009/ads" xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm"><SOAP-ENV:Body>'
	responseXml += '<adm:PlacementResponse '
	if not USE_SOAP:
		responseXml += 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm" '
	if messageId:
		responseXml += 'messageRef="'
		responseXml += messageId
		responseXml += '" '
	responseXml += 'xsi:type="adm:PlacementResponseType">'
	if TESTING == 1:
		responseXml += "JUNKJUNKJUNKJUNKJUNKJUNKJUNKJUNKJUNKJUNKJUNKJUNK";
	else:
		responseXml += '<core:StatusCode xsi:type="core:StatusCodeType" class="'
		responseXml += str(statusCodeClass)
		if statusCodeDetail != 0:
			responseXml += '" detail="'
			responseXml += str(statusCodeDetail)
		responseXml += '">'
		if len(statusCodeNote) > 0:
			responseXml += '<note>'
			responseXml += statusCodeNote
			responseXml += '</note>'
		responseXml += '</core:StatusCode>'
		responseXml += placementDecisions
	responseXml += '</adm:PlacementResponse>'
	if USE_SOAP:
		responseXml += '</SOAP-ENV:Body></SOAP-ENV:Envelope>'
	return attachSuccessHeaders(responseXml)

def createAdsTime(timeSeconds):
	truncTime = int(timeSeconds)
	hours = truncTime / 60 / 60
	minutes = truncTime / 60 % 60
	seconds = truncTime % 60
	result = 'PT'
	if hours != 0:
		result += str(hours) + 'H'
	if minutes != 0 or hours != 0:
		result += str(minutes) + 'M'
	result += str (seconds)
	afterDigit = timeSeconds - truncTime
	if afterDigit != 0:
		result += str(afterDigit)[1:5]
	result += 'S'
	return result

def statusAck():
	successXml = '<?xml version="1.0" encoding="UTF-8"?>\n'
	if USE_SOAP:
		successXml += '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" xmlns:ads="http://www.scte.org/wsdl/130-3/2009/ads" xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm">\n<SOAP-ENV:Body>\n'
	successXml += '<adm:PlacementStatusAcknowledgement '
	if not USE_SOAP:
		successXml += 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm" '
	successXml += 'xsi:type="adm:PlacementStatusAcknowledgementType"></adm:PlacementStatusAcknowledgement>\n'
	if USE_SOAP:
		successXml += '</SOAP-ENV:Body>\n</SOAP-ENV:Envelope>'
	return attachSuccessHeaders(successXml)

def respond(requestRootElem):
	if USE_SOAP:
		if requestRootElem.name != "Envelope":
			return createErrorResponse(requestRootElem.name)
		elems = getChildElems(requestRootElem, "Body")
		if len(elems) != 1:
			return createErrorResponse("Body")
		psnElems = getChildElems(elems[0], "PlacementStatusNotification")
		if len(psnElems) == 1:
			return statusAck()
		elems = getChildElems(elems[0], "PlacementRequest")
		if len(elems) != 1:
			return createErrorResponse("PlacementRequest")
		placementRequestElem = elems[0]
	else:
		if requestRootElem.name == "PlacementStatusNotification":
			return statusAck()
		placementRequestElem = requestRootElem
	messageIdAttr = getAttr(placementRequestElem, "messageId")

	#check the terminal address --- NEW ---/
	clientElem = getChildElems(placementRequestElem, "Client")
	if not clientElem:
		return createErrorResponse("Client")
	terminalAddrElem = getChildElems(clientElem[0],"TerminalAddress")
	if not terminalAddrElem:
		return createErrorResponse("TerminalAddress")
	keyAddrAttr = getAttr(terminalAddrElem[0], "key")
	if keyAddrAttr not in ACTIONS_DICT.keys():
		return createErrorResponse("TerminalAddress")
	# /--- NEW ---

	elems = getChildElems(placementRequestElem, "PlacementOpportunity")
	if len(elems) == 0:
		return createErrorResponse("PlacementOpportunity")
	placementIds = []
	addUnknownEventId = False
	for placementOp in elems:
		idAttr = getAttr(placementOp, "id")
		if idAttr == None:
			return createXmlErrorResponse("PlacementOpportunity/id")
		bindingElems = getChildElems(placementOp, "LinearAvailBinding")
		if len(bindingElems) == 0:
			return createErrorResponse("LinearAvailBinding")
		spliceEventIdAttr = getAttr(bindingElems[0], "spliceEventID")
		if spliceEventIdAttr == None:
			return createXmlErrorResponse("LinearAvailBinding/spliceEventID")
		try:
			UNKNOWN_EVENT_IDS.index(int(spliceEventIdAttr))
			addUnknownEventId = True
		except:
			placementIds.append(idAttr)
	if DEBUG_LEVEL >= 1:
		print "Found", len(placementIds), "placement opportunities"
	
	placementDecisions = ""
	statusCodeClass = 0
	statusCodeDetail = 0
	statusCodeNote = ""
	if addUnknownEventId:
		if len(placementIds) == 0:
			statusCodeClass = 1
		statusCodeDetail = 20
		statusCodeNote = "Unknown spliceEventID"
	for placementIndex in range(len(placementIds)):
		placementDecisionXml = '<adm:PlacementDecision xsi:type="adm:PlacementDecisionType" placementOpportunityRef="' + placementIds[placementIndex] + '" id="PD' + str(placementIndex+1) + '">'
		actions = []
		if ACTIONS_MODE == 0:
			actions = ACTIONS[placementIndex % len(ACTIONS)]
		elif ACTIONS_MODE == 1:
			global cyclicIndex
			cyclicIndex += 1
			if cyclicIndex == len (ACTIONS):
				cyclicIndex = 0
			actions = ACTIONS[cyclicIndex]
		else: # random
			#actions = ACTIONS[random.randint(0, len(ACTIONS) - 1)]
			actions = ACTIONS_DICT[keyAddrAttr][random.randint(0, len(ACTIONS_DICT[keyAddrAttr]) - 1)] # --- NEW ---
		for actionIndex in range(len(actions)):
			action = actions[actionIndex]
			placementDecisionXml += '<adm:Placement xsi:type="adm:PlacementType" action="' + action[0] + '" id="PD' + str(placementIndex+1) + '_P' + str(actionIndex+1) + '">'
			if action[0] == "delete" or action[0] == "fixed":
				if len(action) == 2:
					placementDecisionXml += '<adm:PlacementConstraints xsi:type="adm:PlacementConstraintsType"><core:Duration xsi:type="core:DurationType">'
					placementDecisionXml += createAdsTime(action[1])
					placementDecisionXml += '</core:Duration></adm:PlacementConstraints>'
			else:
				placementDecisionXml += '<core:Content xsi:type="core:ContentType"><AssetRef xsi:type="core:AssetRefType" xmlns="http://www.scte.org/schemas/130-2/2008a/core" assetID="' + action[1] + '" providerID=""></AssetRef><core:Duration xsi:type="core:DurationType">'
				placementDecisionXml += createAdsTime(action[2])
				global trackId
				trackId += 1
				placementDecisionXml += '</core:Duration><core:Tracking xsi:type="core:TrackingType">trackingID-' + str(trackId).zfill (6) + '</core:Tracking></core:Content>'
			placementDecisionXml += '</adm:Placement>'
		placementDecisions += placementDecisionXml + '</adm:PlacementDecision>'
	return createSuccessResponse(placementDecisions, messageIdAttr, statusCodeClass, statusCodeDetail, statusCodeNote)

def main():
	for actionsIndex in range(len(ACTIONS)):
		actions = ACTIONS[actionsIndex]
		for actionIndex in range(len(actions)):
			action = actions[actionIndex]
			error = ""
			if action[0] == "fill" or action[0] == "replace":
				if len(action) != 3 or type(action[2]) != int and type(action[2]) != float:
					error = "Action '" + action[0] + "' takes 2 arguments which are the external id of the ad asset, and the time in seconds"
			elif action[0] == "delete":
				if len(action) != 2 or type(action[1]) != int and type(action[1]) != float:
					error = "Action '" + action[0] + "' takes 1 argument which is the time in seconds"
			elif action[0] == "fixed":
				if len(action) != 1 and (len(action) != 2 or type(action[1]) != int) and type(action[1]) != float:
					error = "Action '" + action[0] + "' takes 1 argument which is the time in seconds"
			else:
				error = "Action '" + action[0] + "' is unknown"
			if error != "":
				print error + " (action " + str(actionIndex+1) + " in splice point " + str(actionsIndex+1) + ")"
				sys.exit(-1)
	
	s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
	s.setsockopt (socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
	s.bind ((LISTEN_IP, LISTEN_PORT))
	s.listen (1)
	timer = Timer()
	while True:
		c = s.accept ()
		if DEBUG_LEVEL >= 2:
			timer.startTimer()
		con = c[0]
		(clientAddr, clientPort) = c[1]
		print
		print "*** New Connection from " + clientAddr + ":" + str(clientPort) + " ***"
		request = ""
		requiredContentLength = 0
		xmlBegin = -1
		connectionTimer = Timer()
		recvIndex = 0
		while True:
			if DEBUG_LEVEL >= 2:
				connectionTimer.startTimer()
			recvIndex += 1
			if DEBUG_LEVEL >= 1:
				print "--- Getting chunk " + str(recvIndex) + " ---"
			rec = con.recv (10000)
			if DEBUG_LEVEL >= 1:
				print "- Chunk -"
				print repr (rec).replace ("\\n", "\n")
				print "- Chunk end -"
			if DEBUG_LEVEL >= 2:
				connectionTimer.stopTimer("Time getting chunk:", 0.001)
			if not rec:
				break
			if DEBUG_LEVEL >= 2:
				connectionTimer.startTimer()
			if USE_SOAP:
				contentLengthHeaderIndex = rec.find ("Content-Length: ")
				if contentLengthHeaderIndex != -1:
					requiredContentLength = int(rec[contentLengthHeaderIndex + len("Content-Length: "):rec.find('\n', contentLengthHeaderIndex)])
			elif recvIndex == 1:
				if rec [:4] != "\x00\x00\x00\x01":
					print "Unexpected beginning of SCTE130-7 header, first bytes expected to be 0x00000001!"
					break
				for lengthByte in rec [4:8]:
					requiredContentLength *= 256
					requiredContentLength += ord(lengthByte)
				if DEBUG_LEVEL >= 1:
					print "Found length " + str (requiredContentLength) + " in SCTE130-7 header"
			request += rec
			if requiredContentLength != 0:
				if xmlBegin == -1:
					xmlBegin = request.find('<?xml')
				if xmlBegin != -1 and xmlBegin + requiredContentLength <= len(request):
					break
			if DEBUG_LEVEL >= 2:
				connectionTimer.stopTimer("Time parsing chunk:", 0.001)
			if DEBUG_LEVEL >= 1:
				print "--- Finished processing chunk " + str(recvIndex) + " ---"
		if DEBUG_LEVEL >= 2:
			connectionTimer.stopTimer("Time parsing chunk:", 0.001)
		if DEBUG_LEVEL >= 1:
			print "--- Finished processing chunk " + str(recvIndex) + " ---"
		request = request[xmlBegin:]
		
		if DEBUG_LEVEL >= 2:
			timer.stopTimer("Time getting request:")
			timer.startTimer()
		requestDoc = libxml2.parseDoc(request)
		rootElem = requestDoc.getRootElement()
		
		if DEBUG_LEVEL >= 2:
			timer.stopTimer("Time parsing XML document:")
			timer.startTimer()
		response = respond(rootElem)	
		if DEBUG_LEVEL >= 2:
			timer.stopTimer("Time parsing request and creating the response:")
		print "*** Sending Response ***"
		if DEBUG_LEVEL >= 1:
			print "- Response -"
			print response[response.find('<?xml'):]
			print "- Reponse end -"
		if TESTING == 2:
			con.send (response)
		con.send (response)
		con.close ()
		print "*** Connection Terminated ***"
		print

main()
