#! /usr/bin/env python2.7
import re
import urllib2
import urlparse
import logging

logger = logging.getLogger('manifest_manipulator.helpers')

TEXT_TYPE = 'text/plain'

XML_TYPE = 'text/xml'

HLS_TYPE = 'application/vnd.apple.mpegurl'

LEVEL_FINDER = re.compile('Level\((.*?)\)')

 # /{static_service}/{channel}/{fregment_length}.{extention}?start={start}&end={end}&device={device_profile}
PROFILE_PARAMS = re.compile('/.*/.*/(.*)(\..*)\?.*device=(.*)')

SIMULATOR_REQ = '<?xml version="1.0" encoding="UTF-8"' + \
'standalone="yes"?>\n<adm:PlacementRequest xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' + \
'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" ' + \
'xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm" messageId="{msg_id}" ' + \
'version="1.1" identity="{identity}" system="adm" updatesAllowed="true"><adm:Client><adm:TerminalAddress ' + \
'key="{zone_name}"></adm:TerminalAddress><adm:TargetCode key="Profile">H264</adm:TargetCode></adm:Client><adm:PlacementOpportunity ' + \
'id="{placement_id}" serviceRegistrationRef="ServiceRef1"><adm:LinearAvailBinding ' + \
'opportunityType="interstitial" spliceEventID="{splice_event_id}"/><adm:PlacementDateTime>{placement_time}' + \
'</adm:PlacementDateTime></adm:PlacementOpportunity></adm:PlacementRequest>\n'

SEGMENT_NUM = re.compile(re.compile("Segment\((.*)\)"))

SIMULATOR_PORT = '9876'

STATIC_VOD = "http://{ip}:{port}/shls/{asset_id}/{fragment_len}{ext}?device={device}"

#not relevant
SIMULATOR_REP = '\x00\x00\x00\x01\x00\x00\x08\xbb<?xml version="1.0" encoding="UTF-8"?>\n' + \
'<adm:PlacementResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' + \
'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:core="http://www.scte.org/schemas/130-2/2008a/core" ' + \
'xmlns:adm="http://www.scte.org/schemas/130-3/2008a/adm" messageRef="20e3af44-a3eb-11e5-8000-000c2926f3af" ' + \
'xsi:type="adm:PlacementResponseType"><core:StatusCode xsi:type="core:StatusCodeType" ' + \
'class="0"></core:StatusCode><adm:PlacementDecision xsi:type="adm:PlacementDecisionType" ' + \
'placementOpportunityRef="20e3af8a-a3eb-11e5-8000-000c2926f3af" id="PD1"><adm:Placement ' + \
'xsi:type="adm:PlacementType" action="replace" id="PD1_P1"><core:Content xsi:type="core:ContentType">' + \
'<AssetRef xsi:type="core:AssetRefType" xmlns="http://www.scte.org/schemas/130-2/2008a/core" ' + \
'assetID="WebUI-1440507751478" providerID=""></AssetRef><core:Duration xsi:type="core:DurationType">' + \
'{duration}</core:Duration><core:Tracking xsi:type="core:TrackingType">trackingID-000001</core:Tracking>' + \
'</core:Content></adm:Placement></adm:PlacementDecision></adm:PlacementResponse>'

def send_url(url,result_type=TEXT_TYPE):
    """
    Send url request and return if the request success and results.
    :param url: the url to send
    :type url: str
    :return: success flag and results
    :rtype: tuple(bool, str)
    """
    logger.debug("Sending url request:%s"%url)
    try:
        resp = urllib2.urlopen(url)
        return resp.read(), resp.getcode(), result_type
    except urllib2.HTTPError, err:
        msg = err.read()
        logger.error("url: %s, HTTP error: %s"%(url, msg))
        return msg, err.code, TEXT_TYPE
    except urllib2.URLError:
        logger.error("url: %s, URL Error"%url)
        return "URL Error", 404, TEXT_TYPE
   

def change_url_host(url, ip, port):
    """
    Gets url, ip and port and returns the same
    url with the new ip and port in the host part. 
    """
    u = urlparse.urlparse(url)
    url = "http://{ip}:{port}{rest}".format(ip=ip, port=port, rest=u.path)
    if u.query:
        url += '?'+u.query
    return url

def get_output_from_url(url, http_type=TEXT_TYPE):
    """
    Returns output dictionary with the following keys
    according to url request and type:
    message<str>, code<int>, succeeded<bool>, type <text>
    """
    output = {}
    output['message'], output['code'], output['type'] = send_url(url, http_type)
    if output['code'] > 299:
        output['succeeded'] = False
    else:
        output['succeeded'] = True
    return output

def get_segment_num_from_uri(uri):
    """
    Returns the segment num in str from uri.
    """
    result = SEGMENT_NUM.findall(uri)
    if result:
        return int(result[0])
    return -1

def replace_in_list(l, val1, val2):
    """
    Replacing val in list.
    If not exist, dont to nothing.
    """
    try:
        i=l.index(val1)
        l[i] = val2
    except ValueError:
        pass
