import socket
import logging
import helpers
from xml.etree.ElementTree import fromstring
from time import sleep
import uuid
from datetime import datetime
import struct


class Simulator(object):

    IDENTITY = "FABRIX_ADM"
    SCTE_START = '\x00\x00\x00\x01'
    PLACEMENT_DECISION_TAG = "{http://www.scte.org/schemas/130-3/2008a/adm}PlacementDecision"
    ASSET_REF_TAG = "{http://www.scte.org/schemas/130-2/2008a/core}AssetRef"

    def __init__(self, ip, port, reconnect=1): 
        self.logger = logging.getLogger("manifest_manipulator.simulator")
        # Connect the socket to the port where the server is listening
        self.server_address = (ip, port)
        self.reconnect = reconnect #1 by default for avoiding performance issues while retrying 

    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        suc = False
        for i in xrange(self.reconnect):
            try:
                self.sock.connect(self.server_address)
                suc = True
                break
            except socket.error, err:
                self.logger.error("Faild to connect simulator in %d try, error %s"%(i,err))
                sleep(1)
        return suc

    def close_connection(self):
        self.logger.info("Closing simulator socket")
        self.sock.close()

    def get_ad_list(self, zone, duration=0, splice_event_id=10000): # defualt until we parse the real one
        #return ['z1','z1','z1'] # JUST FOR NOW
        ad_list = []
        req = self.create_req(splice_event_id, zone)
        resp = self.send_request(req)
        if not resp:
            return []
        ad_list = self.parse_response(resp)
        self.logger.debug("Ad break assets list is {0}".format(ad_list))
        return ad_list

    def send_request(self,req):
        response = ''
        suc = self.connect()
        if suc: 
            try:
                # Send data
                self.logger.debug("Sends %s to simulator"%req)
                self.sock.sendall(req)
                data = 'data' # unimportant txt for the first loop enter
                while data:
                    data = self.sock.recv(1024)
                    response+=data
                self.close_connection()
                self.logger.info("Succeeded to get data from simulator")
                self.logger.debug("Gets %s from simulator"%response)
            except socket.error, err:
                self.logger.error("Failed to ask for data from simulator, error: %s"%err)
                response = ''   
        return response

    def create_req(self,splice_event_id, zone_name):
        msg_id = uuid.uuid1()
        placement_id = uuid.uuid1()
        placement_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        base_req = helpers.SIMULATOR_REQ.format(msg_id=msg_id,
                                            splice_event_id=splice_event_id,
                                            placement_id=placement_id,
                                            placement_time=placement_time,
                                            identity=self.IDENTITY,
                                            zone_name=zone_name)
        header = self.SCTE_START + struct.pack('>L',len(base_req))
        return header + base_req
        

    def parse_response(self, resp):
        asset_ids = []
        xml_beg = resp.find('<?xml')
        if xml_beg != -1:
            resp = fromstring(resp[xml_beg:])
            for c in resp.getchildren():
                if c.tag == self.PLACEMENT_DECISION_TAG:
                    placement=c.getchildren()[0]
                    content=placement.getchildren()[0]
                    for cont in content.getchildren():
                        if cont.tag == self.ASSET_REF_TAG:
                            asset_ids.append(cont.get('assetID'))
        return asset_ids