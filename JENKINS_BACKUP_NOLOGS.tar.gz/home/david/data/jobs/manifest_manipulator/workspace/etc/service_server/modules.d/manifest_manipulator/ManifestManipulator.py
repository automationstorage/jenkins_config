#! /usr/bin/env python2.7

import logging
import re
import m3u8_POC
import helpers
import Simulator
import urllib2

class ManifestManipulator(object):

    DEFUALT_FREGMENT_LENGTH = '4'
    DEFUALT_EXT = '.m3u8'
    DEFUALT_DEVICE = 'HLS'
    # use for set the simulator rate in case there was
    # a problem with the levels bandwidths dictionary
    # it cause to take the high rate. 
    DEFUALT_RATE = 10000000
    MANIPULATING_MODE = 1
    REPLACING_MODE = 2
    FORWORDING_MODE = 3
    
    def __init__(self, streamer_ip, streamer_port, simulator_ip, simulator_port,
                full_path_segments=True, zone='MAC'):

        self.streamer_ip = streamer_ip
        self.streamer_port = streamer_port
        self.full_path_segments = full_path_segments
        self.simulator = Simulator.Simulator(simulator_ip, simulator_port)
        self.fregment_length = self.DEFUALT_FREGMENT_LENGTH
        self.extension = self.DEFUALT_EXT
        self.full_path_ads = True #other cases not supported for now
        self.device_profile = self.DEFUALT_DEVICE
        self.logger = logging.getLogger("manifest_manipulator.manipulator")
        self.level_list = {}
        self.ad_replacment_dict = {}
        self.zone=zone
        self.reset_params()

    def reset_params(self):
        """
        Reset params of manipulator while starting from variant manifest.
        """
        self.logger.info("Reset parameters of manipulator")
        self.current_level = 0
        self.last_ad_name = ''
        self.level_list.clear()
        self.ad_replacment_dict.clear()
        self.current_segment_num = 0
        self.is_out = False
        self.out_last_segment=0
        self.in_last_segment = 0
        self.last_ad_segment = 0
        self.last_segment_value = 0
        self.ads_segments_list = []
        self.manifest_base_path = ''
        self.suc_manipulate = True
        self.duration = 0 # TODO: parse duration from m3u8
        self.ad_bw = 0

    def handle_variant_manifest_req(self, path):
        """
        Gets the variant path and send back an answer after
        taking the variant from streamer.
        """
        self.logger.debug("Got variant manifest")
        self.reset_params() # the same client starts over
        url = helpers.change_url_host(path, self.streamer_ip, self.streamer_port)
        output = helpers.get_output_from_url(url, helpers.HLS_TYPE)
        if output["succeeded"]:
            params = helpers.PROFILE_PARAMS.findall(path)
            if params: #re results
                self.fregment_length, self.extension, self.device_profile = params[0]
                self.logger.debug("fregment_length is %s, extension is %s, device_profile is %s" \
                                %(self.fregment_length, self.extension, self.device_profile))
            else:
                self.logger.warn("Profile parameters not found, path is %s"%path)
            self.update_level_list(output['message'])
            self.logger.debug("Level list is {0}".format(self.level_list))            
        return output

    def handle_level_manifest_req(self, path):
        """
        Gets path of level manifest request and returns
        the manifest after manipulation. 
        """
        self.logger.debug("Got level manifest")
        url = helpers.change_url_host(path,self.streamer_ip,self.streamer_port)
        level = helpers.LEVEL_FINDER.findall(url)
        output = {}
        if not level:
            output['succeeded'] = False
            output['message'] = 'Level not found'
            output['type'] = helpers.TEXT_TYPE
            return output
        self.current_level = int(level[0])
        self.logger.debug("Current level is {0}".format(self.current_level))
        self.set_rate(self.level_list.get(self.current_level,self.DEFUALT_RATE))
        output = helpers.get_output_from_url(url, helpers.HLS_TYPE)
        if output["succeeded"]:
            if self.full_path_segments:
                self.manifest_base_path = "/".join(url.split('/')[:-1]) + '/'
                self.logger.info("Base URL is %s"%self.manifest_base_path)
            output['message'] = self.do_manipulation(output['message'])
        return output

    def handle_streamer_proxy_req(self, path):
        """
        Use as proxy to streamer. Returns the streamer
        response to the path as is in TEXT_TYPE. 
        """
        self.logger.debug("Got proxy handling")
        url = helpers.change_url_host(path,self.streamer_ip,self.streamer_port)
        return helpers.get_output_from_url(url, helpers.XML_TYPE)

    def update_level_list(self,manifest_str):
        """
        Gets variant manifest string and update
        the levels dictionary with the bandwidths
        of the level.
        This list use to set the ad bandwidths closes as we can
        to the program bandwidths in handle_level_manifest_req function.
        """
        manifest = m3u8_POC.loads(manifest_str)
        if manifest.is_variant:
            for p in manifest.playlists:
                stream_info = p.stream_info
                level = helpers.LEVEL_FINDER.findall(p.uri)
                if level:
                    level = int(level[0])
                    self.level_list[level] = stream_info.bandwidth

    def do_manipulation(self, manifest_str):
        """
        Gets manifest string and returns the
        new manifest string after manipulation.
        """
        self.logger.debug("Manipulate manifest")
        manifest = m3u8_POC.loads(manifest_str)
        if manifest.target_duration:
            manifest.target_duration *= 2 #twice time for decrease results of ad segments larger than expected on client play.
        #segments = self._get_last_segments(manifest.segments) # NOT RELEVANT FOR NOW
        segments = manifest.segments
        for seg in segments:
            self.suc_manipulate = True
            self.current_segment_num = helpers.get_segment_num_from_uri(seg.uri)

            # finishing ad-break
            if seg.cue_in:
                self.logger.debug("cue in segment")
                self.is_out = False
                seg.discontinuity=True
                seg.cue_in = False

            # starting ad-break or during ad-break
            elif seg.cue_out:
                self.logger.debug("cue out segment")
                self.is_out = True
                seg.discontinuity = True
                seg.cue_out = False 
                # new ad break, clean ad list.
                if self.current_segment_num > self.out_last_segment:
                    self.ad_replacment_dict.clear()
                    self.ads_segments_list = []
                    self.out_last_segment = self.current_segment_num

            mode = self.FORWORDING_MODE
            # ad segment to manipulate
            if self.is_out and self.current_segment_num > self.last_ad_segment:
                self.last_ad_segment = self.current_segment_num
                mode = self.MANIPULATING_MODE

            # program segment or already manipulated ad segment
            else:
                # already manipulated ad segment
                if seg.uri in self.ad_replacment_dict:
                    mode = self.REPLACING_MODE
                # program segment
                else:
                    mode = self.FORWORDING_MODE                

            if mode == self.MANIPULATING_MODE:
                self.logger.debug("manipulating segment")
                new_seg = self.get_manipulated_segment(seg)
                if new_seg:
                    self.ad_replacment_dict[seg.uri] = new_seg
                    mode = self.REPLACING_MODE
                else:
                    mode = self.FORWORDING_MODE
                    #exit out mode because ads not going as excepted ----- NEW
                    self.logger.warn("Finishing ad break earlier then excepted because an error on getting ad segment.")
                    self.is_out = False
                    seg.discontinuity = True
            
            if mode == self.REPLACING_MODE:
                self.logger.debug("replacing segment")
                helpers.replace_in_list(segments, seg, self.ad_replacment_dict[seg.uri])
            
            elif mode == self.FORWORDING_MODE: 
                self.logger.debug("regular segment")
                seg.uri = self.manifest_base_path + seg.uri

            if not self.suc_manipulate:
                #if failed to manipulate, return the regular segment.
                self.logger.error("Failed manipulate segment %s"%seg.uri)

        self.last_segment_value = self.current_segment_num
        return manifest.dumps() + '\n'

    def get_manipulated_segment(self, seg):
        """
        Change the Uri to be the ts ad segment
        instead of the current one and turn off
        the cue tones signs.
        """
        return self.get_next_ad_segment()

    def get_next_ad_segment(self):
        """
        Returns the next ad segment to use.
        """
        if not self.ads_segments_list:
            self.logger.info("Doing refresh to ad list segments")
            self.refresh_ad_list()
        if not self.ads_segments_list:
            self.logger.error("No ads found")
            self.suc_manipulate = False
            return None
        return self.ads_segments_list.pop(0)
                
    def refresh_ad_list(self):
        """
        Refreshing the ad list of segments.
        """
        #gets external ids of ads
        ad_list = []
        retries = 0 # for not stacking in infinite loop
        # TODO: delete while simulator has a duration!!
        while not ad_list:
            ad_list = self.simulator.get_ad_list(self.zone, self.duration)
            if ad_list:
                if ad_list[0] == self.last_ad_name and retries < 2:
                    ad_list.pop(0)
                retries += 1
            else:
                break
        if ad_list:
            self.last_ad_name = ad_list[-1]

        for ad in ad_list:
            self.logger.debug("Gets data for ad %s"%ad)
            self.ads_segments_list += self.get_segment_list(ad)

    def get_segment_list(self, asset_id):
        """
        Return segments list from external asset id
        :param asset_id: external asset id
        :type asset_id: str

        :return: list of segments
        :rtype: list of m3u8_POC.Segments
        """
        #http://{ip}:{port}/shls/{asset_id}/{fragment_len}{ext}?device={device}
        asset_url = helpers.STATIC_VOD.format(ip=self.streamer_ip,
                                port=self.streamer_port,
                                asset_id=asset_id,
                                fragment_len=self.fregment_length,
                                ext=self.extension,
                                device=self.device_profile)
        try:
            manifest = m3u8_POC.load(asset_url)
        except urllib2.HTTPError,err:
            self.logger.error("url: %s HTTP Error: %s"%(asset_url,err.read()))
            return []
        bandwidths_uris = {}
        if manifest.is_variant:
            for p in manifest.playlists:
                stream_info = p.stream_info
                bandwidths_uris[stream_info.bandwidth] = p.uri
        else:
            #error
            self.logger.error("Didn't get is_variant manifest for %s"%asset_id)
            return []

        bw = self.find_closest_bw(bandwidths_uris.keys())
        level_url = '/'.join(asset_url.split('/')[:-1]) + '/' + bandwidths_uris[bw]
        try:
            manifest = m3u8_POC.load(level_url)
        except urllib2.HTTPError,err:
            self.logger.error("url: %s HTTP Error: %s"%(level_url,err.read()))
            return []
        if not self.full_path_ads:
            adapter_url = ''
        else:
            adapter_url = '/'.join(level_url.split('/')[:-1]) + '/'
        for seg in manifest.segments:
            seg.uri = adapter_url + seg.uri
        if manifest.segments:
            # sign the first segment to be with discontinuity
            # for keep on flow in different ads
            self.logger.debug("Set discontinuity to the first segment")
            manifest.segments[0].discontinuity = True
        return manifest.segments

    def set_rate(self,bw):
        """
        Set the rate of the ad bandwidth
        """
        self.logger.info("New bandwidth for ads set to %d"%bw)
        self.ad_bw = bw

    def find_closest_bw(self,bw_list):
        """
        Find the closes bandwitfh according to list.
        :param bw_list: list of bandwidths
        :type bw_list: list

        :return: the closes value to current bw in list
        :rtype: int
        """
        bw_list.sort()
        lo = 0
        hi = len(bw_list)-1
        while hi-lo > 1:
            mid = int(((float(lo) + float(hi)) / 2.0) + 0.5)
            if bw_list[mid] <= self.ad_bw:
                lo = mid
            else:
                hi = mid
        if self.ad_bw < bw_list[lo]:
            return bw_list[lo]
        elif self.ad_bw > bw_list[hi]:
            return bw_list[hi]
        elif self.ad_bw-bw_list[lo] >= bw_list[hi]-self.ad_bw:
            return bw_list[hi]
        return bw_list[lo]


    ###### NOT RELEVANT - ANALYZE ALL MANIFEST ######
    #def _get_last_segments(self, segments_list):
    #    """
    #    Returns list of segments to manipulate 
    #    according to "last_segments_count" parameter.
    #    The function returns the list from the last segment
    #    we worked on until the end in maximum "last_segments_count"
    #    length or the total list in case the
    #    "last_segments_count" is -1.
    #    """
    #    if self.last_segments_count == -1:
    #        return segments_list
    #    last_segments = segments_list[-self.last_segments_count:]
    #    #find the segment to start with
    #    last_segments.reverse()
    #    for i,seg in zip(xrange(len(last_segments)-1,-1,-1),last_segments):
    #        if (self.last_segment_value != 0 and 
    #        helpers.get_segment_num_from_uri(seg.uri) == self.last_segment_value):
    #            last_segments[0:i]
    #            break
    #    last_segments.reverse()
    #    return last_segments
    ##################################################