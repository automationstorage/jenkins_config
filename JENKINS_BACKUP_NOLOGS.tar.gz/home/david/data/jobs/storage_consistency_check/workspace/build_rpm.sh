VERSION="1.1"
DESCRIPTION="Storage Consistency Files Check"
NAME="storage_consistency_check"

if [ "${BUILD_NUMBER}X" = "X" ] ; then
    exit 1
fi

echo "Removing unnecessary files"
find . -name .svn | xargs rm -rf

echo "Creating directory tree"
mkdir -p Util/scripts/storage_consistency_check/
chmod 755 Util/scripts/

echo "Moving files"
mv *.py Util/scripts/storage_consistency_check
mv *.ini Util/scripts/storage_consistency_check

echo "Fixing permissions"
chmod 755 Util/scripts/storage_consistency_check/*.py
chmod 755 Util/scripts/storage_consistency_check/*.ini

fpm -s dir -t rpm -n ${NAME} --description "${DESCRIPTION}" -v ${VERSION} \
 --iteration ${BUILD_NUMBER} -a noarch --depends "fxVegan => 1.15.1" --config-files /opt/Fabrix.TV/Util/scripts/storage_consistency_check/config.ini \
 --prefix /opt/Fabrix.TV \
Util
