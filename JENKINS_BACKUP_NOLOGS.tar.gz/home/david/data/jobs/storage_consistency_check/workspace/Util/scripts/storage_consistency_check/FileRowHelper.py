﻿#!/usr/bin/env python

import re
import logging

class RaidInfoInvalidError(Exception):
    pass

class FileRowHelper(object):
    """
    Helper class for manage a row from cm_file for creating consistency results
    """
    # represent the output to fill for every row,
    # keys in the name of the value, values in the name of the data field in the DB if exists.
    OUTPUT_LINE = {'File Name': 'file_name',
                   'File ID': 'id',
                   'File creation time': 'c_time',
                   'File permutation': 'storage_units_str',
                   'File RAID segment size': 'raid_info_segment_size',
                   'File RAID chunk size': 'raid_info_chunk_size',
                   'File RAID line size': 'raid_info_line_no',
                   'File RAID size': 'raid_file_size',
                   'File RAID mode' : 'raid_info_raid_mode',
                   'Bucket ID' : 'bucket_id',
                   'Disks Holes' : 'disks_holes', # value will be added by the process
                   'Disks List' : 'disks_list', # value will be added by the process
                   'Asset file state': 'state',  # repairable / corrupt - value will be added by the process
                   'Asset data ID': 'asset_id',  # value will be added by the process
                   'Asset external ID': None,  # will be completed by external post process
                   'Unknown State Reason' : 'unknown_reason' # value will be added by the process
                   }
    # delimiter in the field of the disk permutation from the cm_file table in the DB
    DISK_LIST_DELIMITER = ' '
    # state ids
    CORRUPT_STATE = 'Corrupt'
    REPAIR_STATE = 'Repair'
    FIXED_STATE = 0
    UNKNOWN_STATE = 'Unknown'
    # represent the file path in disks - bucket id will be wrapped by '0' in total length of 8
    FILE_PATH = '/opt/Fabrix.TV/vs-storage/Disk{disk}/Storage_Space/{fs_id}/{bucket_id:0>8}/{file_id}_{perm_index}'
    # fix asset params
    PARSE_ASSET = re.compile('/(.*?)[-\.]')
    # one line function that returns the number of the asset from the filename
    ASSET_ID_FINDER = lambda self,file_name: self.PARSE_ASSET.findall(file_name)[0]

    def __init__(self, row_dict):
        """
        :param row_dict: cm_file row dict according to 'BUCKET_FILE_LIST_CHUNK' in queries file
        :type row_dict: dict
        """
        self.row = row_dict
        self.row['state'] = self.FIXED_STATE
        self.row['disks_holes'] = [] # after getting output line - this value become string!
        self.row['disks_list'] = [] # after getting output line - this value become string!
        self.row['unknown_reason'] = ''
        self.row['asset_id'] = self.ASSET_ID_FINDER(self.row['file_name'])
        self.missing_segment_part = []
        self.logger = logging.getLogger("StorageConsistencyCheck.FileRowHelper")
        self.more_info_writer = logging.getLogger("StorageConsistencyCheck-MoreInfo.Row").debug
        # if one of the following, every missing part will cause to corruption
        if self.row['raid_info_segment_size'] == 1 or self.row['raid_info_raid_mode'] == 0:
            self.always_corrupt  = True
        else:
            self.always_corrupt = False

    def add_missing_file_part(self, storage_index, index_on_permutation):
        """
        Update missing file part by checking if the missing lead to corrupt state or repaire state
        :param index_on_permutation: the index of the disk 
        :type index_on_permutation: int
        """
        self.more_info_writer(("Add missing file part: storage_index={0}, index_on_permutation={1}, " + \
                               "always_corrupt={2}, state={3}, missing_segment_part={4}").format(
            storage_index, index_on_permutation, self.always_corrupt, self.row['state'], self.missing_segment_part))
        self.row['disks_holes'].append(storage_index)
        if self.always_corrupt:
            self.row['state'] = self.CORRUPT_STATE
        # if the file is already corrupt, there is not need to check.
        elif self.row['state'] != self.CORRUPT_STATE:
            segment_part = index_on_permutation / self.row['raid_info_segment_size']
            self.more_info_writer("Missing on segment: %d"%segment_part)
            if segment_part in self.missing_segment_part:
                self.row['state'] = self.CORRUPT_STATE
            else:
                self.row['state'] = self.REPAIR_STATE
                self.missing_segment_part.append(segment_part)

    def get_file_path(self, disk_id, index_on_permutation):
        """
        Build full file path
        :param disk: The disk id
        :type disk: str (can be int also)
        :param index_on_permutation: The index of the disk in the permutation
        :type index_on_permutation: int
        """
        return self.FILE_PATH.format(disk=disk_id,
                                     fs_id=self.row['fs_id'],
                                     bucket_id=self.row['bucket_id'],
                                     file_id=self.row['id'],
                                     perm_index=index_on_permutation)

    def get_state(self):
        return self.row['state']

    def set_unknown_state(self, reason):
        self.more_info_writer("Set unknown state: reason=%s"%reason)
        self.row['state'] = self.UNKNOWN_STATE
        self.row['unknown_reason'] = reason

    def get_output_line(self):
        """
        Returns dict that represent the output line data
        """
        self.row['disks_holes'] = self.DISK_LIST_DELIMITER.join([str(h) for h in self.row['disks_holes']])
        self.row['disks_list'] = self.DISK_LIST_DELIMITER.join([str(d[1]) for d in self.row['disks_list']])
        output_dict = {}
        for output_val, row_val in self.OUTPUT_LINE.items():
            output_dict[output_val] = self.row.get(row_val, None)
        return output_dict

    def get_disk_list(self):
        """
        Returns the disk list to check
        :return: list of disks with their index on permutation in form of (index, disk)
        :rtype: list of tupples
        """
        disk_list = []
        permutation_list = map(int,self.row['storage_units_str'].split(self.DISK_LIST_DELIMITER))
        line_size_in_bytes = self.row['raid_info_line_no'] * self.row['raid_info_chunk_size']
        # more than one line is used - should result all the permutation
        if self.row['raid_file_size'] > line_size_in_bytes:
            disk_list = list(enumerate(permutation_list))
        # only part of the permutation is used - check which disks should be resulted
        # verify that the file has a size
        elif self.row['raid_file_size'] > 0:
            # get num of chunks (round up)
            chunks_num = int(self.row['raid_file_size'] / self.row['raid_info_chunk_size']) + \
                            (self.row['raid_file_size'] % self.row['raid_info_chunk_size'] > 0)
            full_segment_num = int(chunks_num / self.row['raid_info_segment_size'])
            last_index_of_full_segments = full_segment_num * self.row['raid_info_segment_size']
            # fill the disk list according to the num of full segments
            disk_list = list(enumerate(permutation_list[:last_index_of_full_segments]))
            rest_chunks_num = chunks_num % self.row['raid_info_segment_size']
            if rest_chunks_num > 0:
                disk_list += list(enumerate(permutation_list[last_index_of_full_segments:last_index_of_full_segments+rest_chunks_num],
                                            last_index_of_full_segments))
                # find the last disk that does not count in such cases
                # reduce 1 from the result since the first index of the list is 0
                last_parity_index = (full_segment_num + 1) * self.row['raid_info_segment_size'] - 1
                disk_list.append((last_parity_index, permutation_list[last_parity_index]))
        self.more_info_writer("Created disk list to check: {0}".format(disk_list))
        self.row['disks_list'] = disk_list
        return disk_list
