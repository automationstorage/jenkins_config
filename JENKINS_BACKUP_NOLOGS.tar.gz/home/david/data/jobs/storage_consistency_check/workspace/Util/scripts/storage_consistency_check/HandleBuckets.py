﻿#! /usr/bin/env python2.7

import os
import re
import glob
import logging
import commands
from datetime import datetime
from fxVegan import caching_utils
from fxVegan import request_utils
import xml.etree.cElementTree as ET

class AddressInvalidError(Exception):
    pass

class InvalidStorageParamsError(Exception):
    pass

class PreConditionFailed(Exception):
    pass

class BucketManager(object):
    """
    Represent a bucket
    """
    BUCKET_DATA_POSTFIX = '.pkl'
    BUCKET_DATA_FILE_NAME = 'rawBucket{0}' + BUCKET_DATA_POSTFIX
    IPS_NODES_DICT = {}
    POD_DICT = {}

    # storage issues
    INVALID_DISK_STATUS = '1'
    DISK_FAULTY_STR = "Disk {addr} has been down on the last examination ({time})"
    DISK_MISSING_STATUS_STR = "Disk {addr} has been missing from FX_Get_Storage_State service ({time})"
    DISK_MISSING_IN_DB_STR = "Disk {addr} has been missing from DB (cm_fs_storage_units table)"
    SYSU_FAILED_STR = "Mapping node {node} command has returned failure ({time})"

    # use file
    STORAGE_USE_FILE = '/opt/Fabrix.TV/Storage/bin/storage-server.use'
    HTTP_SERVER_PORT = 4111
    CLUSTER_STORAGE_PORT_RANGE = 1000

    # errors codes
    SYSU_FAILED_CODE = 1
    SUCCESS_CODE = 0

    ### get output commands ###
    # general sysu for running commands on external nodes
    SYSU_REMOTE_COMMAND_PREFIX = "sysu -N {node} -m run.shell2 -c '%s'"

    # function for getting the host name using sysu
    GET_NODE_NAME_FUNCTION = staticmethod(lambda ip: commands.getoutput(
        "sysu ls.nodes -r ips -vv | grep -B 2 {ip} | grep -v -e '^$' | head -1".format(ip=ip)))

    # function for getting the file list of the node and the bucket using sysu
    GET_FILES_LIST_FUNCTION = staticmethod(lambda host, bucket_id: commands.getstatusoutput(
        (BucketManager.SYSU_REMOTE_COMMAND_PREFIX%(
        "find /opt/Fabrix.TV/vs-storage/Disk*/Storage_Space/*/{bucket_id:0>8}/ -type f")
         ).format(node=host, bucket_id=bucket_id)))

    # fucntion for getting the use file string usinig sysu
    GET_USE_FILE_FUNCTION = staticmethod(lambda node : commands.getoutput(
        (BucketManager.SYSU_REMOTE_COMMAND_PREFIX%(
            "cat " + BucketManager.STORAGE_USE_FILE)
         ).format(node=node)))

    DISKS_STATUR_URL = "http://{manager}:5929/FX_CM_Service/FX_Get_Storage_State?storage_name=&storage_port=0"

    lambda : commands.getoutput(SYSU_REMOTE_COMMAND_PREFIX%("cat " + STORAGE_USE_FILE))

    lambda host, bucket_id: commands.getstatusoutput(SYSU_REMOTE_COMMAND_PREFIX%(
        "find /opt/Fabrix.TV/vs-storage/Disk*/Storage_Space/*/{bucket_id:0>8}/*").format(
            node=node, bucket_id=bucket_id))

    @staticmethod
    def update_ips_node_dict():
        """
        Static Method: Update the class variable of node and ips dictionary
        """
        if not BucketManager.POD_DICT:
            raise PreConditionFailed("Pod list is empty")

        ips = set([addr[0] for addr in BucketManager.POD_DICT.values()])
        for ip in ips:
            node = BucketManager.GET_NODE_NAME_FUNCTION(ip)
            if not node:
                logging.getLogger("StorageConsistencyCheck.Bucket").warning("Can't find node name for ip %s"%ip)
            else:
                BucketManager.IPS_NODES_DICT[ip] = node

        if not BucketManager.IPS_NODES_DICT:
            raise PreConditionFailed("Nodes list is empty")

    @staticmethod
    def create_pod_dict(pod_rows_data):
        """
        Static Method: Update the class variable of pod and ips dictionary
        :param pod_rows_data: rows data of cm_fs_storage_units table
        :type pod_rows_data: iterable dictionaries (list or iterator)
        """
        for pod in pod_rows_data:
            BucketManager.POD_DICT[(pod['top_id'], pod['elem_id'])] = (pod['addrs_name'], pod['addrs_port'])

    @staticmethod
    def update_storage_use_params(storage_server_ip):
        """
        Gets relevant prameters from use file and update them on class level.
        """
        logger = logging.getLogger("StorageConsistencyCheck.Bucket")
        try:
            # get use file str - external file
            if storage_server_ip not in ('127.0.0.1', 'localhost'):
                logger.debug("Get external use file")
                storage_server_node = BucketManager.GET_NODE_NAME_FUNCTION(storage_server_ip)
                use_file = BucketManager.GET_USE_FILE_FUNCTION(storage_server_node)
            # local file
            else:
                logger.debug("Get local use file")
                use_file = open(BucketManager.STORAGE_USE_FILE, 'rb').read()
            logger.debug("Use file string starting with : %s"%use_file[:100])
            # parse params
            BucketManager.CLUSTER_STORAGE_PORT_RANGE = int(re.findall('# CLUSTER_STORAGE_PORT_RANGE = (.*)',use_file)[0])
            BucketManager.HTTP_SERVER_PORT = int(re.findall('# HTTP_SERVER_PORT = (.*)',use_file)[0])
        except (IndexError, IOError):
            logger.warning("Can not parse the following parameters from use file: " + \
                           "CLUSTER_STORAGE_PORT_RANGE and HTTP_SERVER_PORT, " + \
                           "use defulat params:".format(BucketManager.STORAGE_USE_FILE) + \
                           "CLUSTER_STORAGE_PORT_RANGE={0}, HTTP_SERVER_PORT={1}".format(BucketManager.CLUSTER_STORAGE_PORT_RANGE,
                                                                                         BucketManager.HTTP_SERVER_PORT))

        finally:
            logger.info("CLUSTER_STORAGE_PORT_RANGE=%d, HTTP_SERVER_PORT=%d"%(BucketManager.CLUSTER_STORAGE_PORT_RANGE,
                                                                              BucketManager.HTTP_SERVER_PORT))


    @staticmethod
    def remove_bucket_files(root_dir):
        """
        Static Method: remove files that have been reated by the class
        :param root_dir: the root dir that include the files
        :type root_dir: str
        """
        for f in glob.glob(os.path.join(root_dir, "*" + BucketManager.BUCKET_DATA_POSTFIX)):
            os.remove(f)

    def __init__(self, bucket_id, root_folder, manager_ip):
        """
        :param bucket_id: the id of the bucket
        :type bucket_id: int
        :param root_folder: the root dir that include the files
        :type root_folder: str
        """
        self.logger = logging.getLogger("StorageConsistencyCheck.Bucket")
        self.id = bucket_id
        self.manager_ip = manager_ip
        self.pod_list = self.POD_DICT.values()
        self.bucket_path = os.path.join(root_folder, self.BUCKET_DATA_FILE_NAME.format(bucket_id))
        self.logger.info("New bucket object: id={0}, path={1}".format(bucket_id, self.bucket_path))
        # open issued params
        self.disks_status_dict = {}
        self.last_update_node_statue_time = datetime.min
        self.last_update_disks_status_time = datetime.min
        # start processing
        self.bucket_data_dict = caching_utils.PickleStateDict(self.bucket_path, autosave=False)
        self.load_bucket_data()
        self.update_disks_status()

    def update_disks_status(self):
        """
        Update the status of the disks (up/down) using manager service.
        """
        self.logger.info("Update disks status info")
        result = request_utils.get_url_safety(self.DISKS_STATUR_URL.format(manager=self.manager_ip))
        if result['success'] == False:
            self.logger.error("Could not calculate disks status: %s"%result['output'])
            raise AddressInvalidError("Could not calculate disks status: %s"%result['output'])
        output = ET.fromstring(result['output'])
        storage_units = output.find('storages')
        for unit in storage_units:
            if unit.tag == 'elem':
                addr = unit.find('storage_addr')
                if addr is not None:
                    # if status is not exist - it will be None. the checking is on ivalid value = '1'
                    self.disks_status_dict[(addr.findtext('name'),int(addr.findtext('port')))] = unit.findtext('status')
                else: 
                    self.logger.error('Cant find address for unit: %s'%ET.dump(unit))
        self.last_update_disks_status_time = datetime.now()
        self.logger.debug("Disks status was last updated on {0}. Status is {1}".format(self.last_update_disks_status_time, self.disks_status_dict))

    def load_bucket_data(self):
        """
        Get bucket data - from cache of from nodes
        """
        self.logger.info("Load bucket data")
        # if data does not exist in cache, get new one
        if not self.bucket_data_dict:
            self.get_bucket_data()

    def get_bucket_data(self):
        """
        Get data of bucket from all nodes
        """
        self.logger.debug("Get data of bucket")
        self.last_update_node_statue_time = datetime.now()
        for ip, node in self.IPS_NODES_DICT.items():
            self.bucket_data_dict[ip] = self.get_node_data(node)
        self.logger.debug("Save data of bucket")
        self.bucket_data_dict.save()

    def get_node_data(self, node):
        """
        Get data of bucket from specific node
        :param node: node
        :type node: str

        :return: the status of getting results and the results. 
        :rtype: dict (keys: status, results)
        """
        self.logger.debug("Get data from node: {0}".format(node))
        status, results = self.GET_FILES_LIST_FUNCTION(node, self.id)
        # an error occurred
        if status != 0:
            self.logger.error("Failed to update file list: " + 
                              "bucket={0}, host={1}, status={2}, results={3}".format(self.id,
                                                                                    node,
                                                                                    status,
                                                                                    results))
            return {"status" : self.SYSU_FAILED_CODE, "results" : []}
        else:
            # edit results
            results = results.replace("\n",'')
            results = results.split(node+": ")
            return {"status" : self.SUCCESS_CODE, "results" : results}

    def get_disk_issues(self, disk_addr):
        """
        Returns an issues of the disk if files cany being checked while written on the disk
        :param disk_addr: The disk ip and port
        :type disk_addr: tuple
        :return: The issue if ther is one or an empty string
        :rtype: str
        """
        # disk has bad status
        if self.disks_status_dict.has_key(disk_addr):
            if self.disks_status_dict[disk_addr] == self.INVALID_DISK_STATUS:
                return self.DISK_FAULTY_STR.format(addr=disk_addr,time=self.last_update_disks_status_time)
        # disk does not appear in status
        else:
            self.logger.warning("Disk {0} cannot be found in FX_Get_Storage_State service result".format(disk_addr))
            return self.DISK_MISSING_STATUS_STR.format(addr=disk_addr,time=self.last_update_disks_status_time)
        # disk does not have a mapping
        if self.IPS_NODES_DICT.has_key(disk_addr[0]) and self.bucket_data_dict.has_key(disk_addr[0]):
            if self.bucket_data_dict[disk_addr[0]]["status"] == self.SYSU_FAILED_CODE:
                return self.SYSU_FAILED_STR.format(node=self.IPS_NODES_DICT[disk_addr[0]],time=self.last_update_node_statue_time)
        # disk does not include in the disk list from the DB
        else:
            return self.DISK_MISSING_IN_DB_STR.format(addr=disk_addr)
        # no issues found
        return ''

    def is_file_exist(self, disk_ip, file_path):
        """
        :param disk_ip:
        :type disk_ip:
        :param file_path: full file pathn according to storage form such as FileRowHelper.FILE_PATH
        :type file_path: str
        """
        #check if disk addr ip exists in bucket data dict
        if self.bucket_data_dict.has_key(disk_ip):
            return (file_path in self.bucket_data_dict[disk_ip]["results"])
        else:
            self.logger.error("Disk {0} cannot be found in dictionary! pod list is {1}".format(disk_ip, self.pod_list))
            raise AddressInvalidError("Disk %s cannot be found in dictionary!" % disk_ip)

    def get_disk_addr(self, fs_name, storage_index):
        """
        Returns the disk address
        :param fs_name: fs_name value in cm_file of specific raw
        :type fs_name: str
        :param index_on_permutation: the index of the disk in permutation(storage_units_str)
        :type index_on_permutation: int
        
        :return: disk addr - ip,port
        :rtype: tuple
        """
        return self.POD_DICT[(fs_name, storage_index)]

    def get_disk_id(self, disk_port):
        """
        Returns the id of the disk folder /opt/Fabrix.TV/vs-storage/DiskX
        :param disk_port: the disk port
        :type disk_port: int
        """
        return ((disk_port - self.HTTP_SERVER_PORT) / self.CLUSTER_STORAGE_PORT_RANGE) + 1
