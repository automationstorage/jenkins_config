﻿#!/usr/bin/env python27

import time
import optparse
from StorageConsistencyChecker import StorageConsistencyChecker

def parse_args():
    usage = "usage: %prog [options]"
    parser = optparse.OptionParser(description=__doc__, usage=usage)
    parser.add_option('-i', '--ini-file', default=None, type="str",
        help="The path to the ini config file. MANDATORY.")
    parser.add_option("--remove-files", action="store_true", default=False,
        help="Remove all script files. USE IT CAUTIOUSLY!")
    parser.add_option("--more-info", action="store_true", default=False,
        help="Create log with script's decisions for every storage file in details. " + \
        "Should be used for deeply debugging. " + \
        "WARNING: a large amount of data could be created while using this flag. Use it for limited time!")

    options, args = parser.parse_args()

    if (not options.ini_file):
        parser.error('INI configuration file has not been given')

    return options 

def main():
    tmp = time.time()
    options = parse_args() 
    checker = StorageConsistencyChecker(options.ini_file, options.more_info)
    if options.remove_files:
        print "Removing migration files..."
        checker.remove_script_files()
    else:
        print "Starting storage consistancy check..."
        checker.star_processing()

    print 'Total Completed in %f seconds'%(time.time() - tmp)

if __name__ == '__main__':
    main()
