﻿# Filter out : Files which are not Master files - do not have Type = 1 (Master)
#              Files with state = 3 (Corrupted) / 7 (During Delete)
#              Files which are recent
BUCKET_FILE_LIST_CHUNK = "SELECT index, file_name, id, c_time, storage_units_str, raid_file_size, fs_id, fs_name, " + \
                         "raid_info_chunk_size, raid_info_line_no, raid_info_segment_size, bucket_id, raid_info_raid_mode " + \
                         "FROM cm_file " + \
                         "WHERE bucket_id = {bucket_id} AND index > {last_index} AND state not in (3,7) AND type = 1 AND c_time < '{max_time}' " + \
                         "ORDER BY index " + \
                         "LIMIT {chunk_size}"

STORAGE_UNIT_LIST = "SELECT top_id, elem_id, addrs_port, addrs_name " + \
                    "FROM cm_fs_storage_units"

ASSET_FIXED = "SELECT data_id, external_id FROM asset WHERE data_id in ({id_list})"
