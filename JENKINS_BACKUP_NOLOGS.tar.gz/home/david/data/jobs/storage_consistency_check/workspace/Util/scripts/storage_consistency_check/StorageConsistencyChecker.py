﻿#! /usr/bin/env python2.7

## Python Modules ##
import os
import csv
import glob
import queries
import logging
from threading import Thread
from datetime import datetime, timedelta

## Script Modules ##
import queries
import HandleBuckets
from fxVegan import db_utils
from fxVegan import log_utils
from fxVegan import config_utils
from fxVegan import report_utils
from fxVegan import caching_utils
from FileRowHelper import FileRowHelper, RaidInfoInvalidError

class UnMatchIdsError(Exception):
    pass

class StorageConsistencyChecker(object):

    # Script files
    SCRIPT_FILES_POSTFIX = '.storage_con'
    BUCKET_INDEXES_CACHE_FILE_NAME = 'last_bucket_index' + SCRIPT_FILES_POSTFIX
    SUMMARY_CACHE_FILE_NAME = 'summary_cache' + SCRIPT_FILES_POSTFIX
    MORE_INFO_FILE_NAME = "more_info" + SCRIPT_FILES_POSTFIX

    # Process params
    BUCKETS_COUNT = 64

    # DB param - ~*~*TODO: generic driver*~*~
    SOLID_CONNECT_STRING = 'DRIVER=libsocl2x6465.so;DSN=tcp %s 2315'

    # Summary params
    DISK_HOLES = '4. Disks Holes'
    FILE_COUNT = '1. Total Files Count'
    REPAIR_COUNT = '2. Total Repairable Count'
    CORRUPT_COUNT = '3. Total Corrupted Count'
    UNKNONW_COUNT = '5. Total Unknown State Count'
    DISK_STRING = "Disk{0} - {1}"

    def __init__(self, conf_file, more_info=False):
        """
        :param conf_file: configuraion path
        :type conf_file: str
        """
        self.parse_configuration(conf_file)
        # init params
        self.next_bucket_index = 0
        self.next_index_file = 0
        self.db_connector = db_utils.SolidODBCConnection(dsn=self.SOLID_CONNECT_STRING % self.db_host)
        self.output_lines = []
        self.columns = FileRowHelper.OUTPUT_LINE.keys()
        # The output keys will be ordered alphabeticaly in the CSV file for get a logical order in the output
        self.columns.sort()
        # cache objects
        self.bucket_last_index = caching_utils.PickleStateDict(self.BUCKET_INDEXES_CACHE_FILE_NAME, scriptfile=(self.root_dir + "/*"), autosave=False)
        self.summary_dict = caching_utils.PickleStateDict(self.SUMMARY_CACHE_FILE_NAME, scriptfile=(self.root_dir + "/*"), autosave=False)
        # update cache for the first time if the cache is empty
        if not self.summary_dict:
            self.summary_dict.update({self.DISK_HOLES : {},
                                      self.FILE_COUNT : 0,
                                      self.CORRUPT_COUNT : 0,
                                      self.UNKNONW_COUNT : 0,
                                      self.REPAIR_COUNT : 0})
        if not self.bucket_last_index:
            self.bucket_last_index.update({'current' : 0,
                                           'last_index' : 0})
        # handle log
        log_utils.set_rot_file_log(self.log_path,
                                   fmt='%(asctime)s\t%(name)s\t%(levelname)s\t%(message)s',
                                   size=self.log_size,
                                   backups=self.rotations,
                                   loggers = [logging.getLogger("StorageConsistencyCheck"), logging.getLogger("fxVegan")])
        # logging.DEBUG determine the scale of the total verbosity for setLeven function
        logging.getLogger("StorageConsistencyCheck").setLevel(self.verbosity * logging.DEBUG)
        # info only - if changing on future, 
        # be aware that fxVegan.caching_utils.file_cache should not be on debug mode!
        logging.getLogger("fxVegan").setLevel(logging.INFO)
        logging.getLogger("fxVegan.db_utils.SolidODBCConnection").setLevel(self.verbosity * logging.DEBUG)
        self.logger = logging.getLogger("StorageConsistencyCheck.Checker")
        
        # handle more info log
        if more_info:
            log_utils.set_rot_file_log(os.path.join(self.root_dir,self.MORE_INFO_FILE_NAME),
                                       fmt='%(asctime)s\t%(name)s\t%(levelname)s\t%(message)s',
                                       loggers = [logging.getLogger("StorageConsistencyCheck-MoreInfo")])
        self.more_info_writer = logging.getLogger("StorageConsistencyCheck-MoreInfo.Checker").debug
        
        self.logger.info('Initialize storage consistency check: root-dir=%s, log_path=%s, max_time=%s'
                         % (self.root_dir, self.log_path, self.max_time))
        self.more_info_writer("----- New running ------")

    def parse_configuration(self, path):
        """
        Parse configuration file and initialize class parameters
        :param path: configuraion path
        :type path: str
        """
        conf = config_utils.get_config(path)
        # [General]
        self.root_dir = conf.get("General", "rootDir")
        self.storage_server = conf.get("General", "storageServer")
        # [Output]
        self.csv_path = conf.get("Output", 'filesDemagedPath')
        self.summary_path = conf.get("Output", 'summaryPath')
        # [Solid]
        self.db_host = conf.get("Solid", "host")
        self.dbchunk_size = conf.getint("Solid", "chunkSize")
        self.assetfix_chunk = conf.getint("Solid","chunkInSize")
        # [Log]
        self.log_path = conf.get("Log", "path")
        self.log_size = conf.getsize("Log", "size")
        self.rotations = conf.getint("Log", "rotations")
        self.verbosity = conf.getint("Log", "verbosity")
        # [Logic]
        if conf.getboolean("Logic", "useRecency"):
            recency = conf.getint("Logic", "recency")
            self.max_time = datetime.utcnow() - timedelta(seconds=recency)
        else:
            time = conf.get("Logic", "maxTime")
            self.max_time = datetime.strptime(time,"%Y-%m-%d %H:%M:%S.%f")
        self.manager_ip = time = conf.get("Logic", "managerIp")

    def remove_script_files(self):
        """
        Remove script files according to the script prefix from root dir
        """
        self.logger.info("Remove script files")
        [os.remove(f) for f in glob.glob(os.path.join(self.root_dir, "*" + self.SCRIPT_FILES_POSTFIX))]
        HandleBuckets.BucketManager.remove_bucket_files(self.root_dir)
        if os.path.exists(self.csv_path):
            print "\nWARNING: %s already exists in the system."%self.csv_path
            print "For clean run, remove file or save it in another name. Otherwise, new data will be added to the same file.\n"

    def pre_processing(self):
        """
        Preparations for run logic - create dictionaries for processing information
        """
        self.logger.info("Start pre processing")
        self.logger.debug("Create pod dict")
        HandleBuckets.BucketManager.create_pod_dict(self.db_connector.execute_to_dict(queries.STORAGE_UNIT_LIST))
        self.logger.debug("Update mapping of pod ips and VSPP nodes")
        HandleBuckets.BucketManager.update_ips_node_dict()
        self.logger.debug("Update storage's parameters from use file")
        HandleBuckets.BucketManager.update_storage_use_params(self.storage_server)
        self.logger.debug("pod_list={0}".format(HandleBuckets.BucketManager.POD_DICT))
        self.logger.debug("ips_nodes={0}".format(HandleBuckets.BucketManager.IPS_NODES_DICT))

    def star_processing(self):
        """
        Check storage consistency on chunk files for every bucket
        """
        self.pre_processing()
        self.logger.info("Start processing")
        for bucket in self.get_next_bucket():
            self.logger.info("Start Working on bucket id {0}".format(bucket.id))
            for dbchunk in self.get_next_dbchunk_bucket(bucket.id):
                self.logger.debug("Start processing bucket chunk - last row index is {0}".format(dbchunk[-1]['index']))
                for row in dbchunk:
                    try:
                        self.handle_file_row(row, bucket)
                    except RaidInfoInvalidError:
                        pass
                self.add_asset_data()
                # save cache using thread to prevent key interruption while saving data.
                save_thread = Thread(target=self.save_bucket_data)
                save_thread.start()
                # wait until the saving is over
                save_thread.join()
                self.logger.debug("Finish handle bucket {0} chunk".format(bucket.id))
            self.logger.info("Finish working on bucket {0}".format(bucket.id))
        self.aggregate_consistency_data()
        self.logger.debug("Close DB session")
        self.db_connector.conn.close()
        self.logger.info("Finish storage consistency check")

    def save_bucket_data(self):
        """
        Save bucket chunk rows and current cache
        """
        self.logger.debug("Save data of bucket chunk")
        # write rows
        if self.output_lines:
            report_utils.rows_dict_to_csv(self.csv_path, self.output_lines, self.columns)
            self.logger.debug("First row to be written in the csv is {0}".format(self.output_lines[0]))
            self.output_lines = []
        # update cache
        self.logger.debug("Update buckets indexes cache - {0}".format(self.bucket_last_index))
        self.bucket_last_index.save()
        self.logger.debug("Update summary cache - {0}".format(self.summary_dict))
        self.summary_dict.save()

    def add_asset_data(self):
        """
        Add asset external id to the output rows using queries of IN (..) form
        """
        self.logger.debug("Fix asset data on rows")
        for rows in self.get_assetfix_chunk():
            # connect between the row index and the asset id
            map_index_id = {}
            # map the asset internal id to the index row for comlete the external id after running the query
            for index_row in xrange(len(rows)):
                map_index_id[rows[index_row]['Asset data ID']] = index_row
            results = self.db_connector.execute_to_dict(queries.ASSET_FIXED.format(id_list=','.join(map_index_id.keys())))
            for result in results:
                index_row = map_index_id[str(int(result['data_id']))]
                rows[index_row]['Asset external ID'] = result['external_id']

    def get_assetfix_chunk(self):
        """
        Generator that creates chunks on rows for asset fix query
        :return: chunk of output rows
        :rtype: list
        """
        current = min = 0
        max = len(self.output_lines)
        while current < max:
            self.logger.debug("Fix {0} assets data from {1}/{2}".format(self.assetfix_chunk, current, max))
            yield self.output_lines[current:current + self.assetfix_chunk]
            current = current + self.assetfix_chunk

    def get_next_bucket(self):
        """
        Generator that returns the next bucket to work on
        :return: the bucket 
        :rtype: HandleBuckets.BucketManager
        """
        # the first run is always continuing - from exists cache or from init values
        new_bucket = False
        for i in xrange(self.bucket_last_index['current'], self.BUCKETS_COUNT):
            if new_bucket:
                self.bucket_last_index.update({'current':i,'last_index':0})
            print "%s: Working on bucket %d"%(datetime.now(),i)
            yield HandleBuckets.BucketManager(i, self.root_dir, self.manager_ip)
            new_bucket = True

    def get_next_dbchunk_bucket(self, bucket_id):
        """
        Generator that returns the next chunk of a bucket to work on
        :param bucket_id: the id of the bucket
        :type bucket_id: int
        :return: rows chunk from cm_file of the bucket_id
        :rtype: list of dict
        """
        if bucket_id != self.bucket_last_index['current']:
            raise UnMatchIdsError("Current bucket {0} is different from the given bucket id {1}".format(self.bucket_last_index['current'],bucket_id))
        # init result for first time looping
        result = [None]
        while result:
            self.logger.debug("Get bucket chunk from DB from inedx {0}".format(self.bucket_last_index['last_index']))
            result = self.db_connector.execute_to_dict(queries.BUCKET_FILE_LIST_CHUNK.format(bucket_id=bucket_id,
                                                                                              last_index=self.bucket_last_index['last_index'],
                                                                                              max_time=self.max_time,
                                                                                              chunk_size=self.dbchunk_size))
            result = list(result)
            if result:
                self.bucket_last_index['last_index'] = result[-1]['index']
                yield result

    def handle_file_row(self, row, bucket):
        """
        Handle full specific file check
        :param row: row from cm_file table
        :type row: dict
        :param bucket: a bucket object
        :type bucket: HandleBuckets.BucketManager
        """
        file_row = FileRowHelper(row)
        self.more_info_writer("Handle row {0}".format(row))
        for index_on_permutation, storage_index in file_row.get_disk_list():
            # ip and port
            disk_addr = bucket.get_disk_addr(row['fs_name'], storage_index)
            # id of the disk folder 'DiskX'
            disk_id = bucket.get_disk_id(disk_addr[1])
            # full path to the folder
            file_path = file_row.get_file_path(disk_id, index_on_permutation)
            # key for ordering the summary counts
            disk_key = self.DISK_STRING.format(disk_id, disk_addr[0])
            # issues that signs for inability status check
            open_issues = bucket.get_disk_issues(disk_addr)
            self.more_info_writer("disk_addr={0}, disk_id={1}, file_path={2}, open_issues={3}".format(
                disk_addr, disk_id, file_path, open_issues))
            if open_issues:
                file_row.set_unknown_state(open_issues)
                break
            elif not bucket.is_file_exist(disk_addr[0], file_path):
                file_row.add_missing_file_part(storage_index, index_on_permutation)
                self.summary_dict[self.DISK_HOLES][disk_key] = self.summary_dict[self.DISK_HOLES].get(disk_key, 0) + 1
        # manage state
        if file_row.get_state() != FileRowHelper.FIXED_STATE:
            self.output_lines.append(file_row.get_output_line())
            if file_row.get_state() == FileRowHelper.CORRUPT_STATE:
                self.summary_dict[self.CORRUPT_COUNT] += 1
            elif file_row.get_state() == FileRowHelper.REPAIR_STATE:
                self.summary_dict[self.REPAIR_COUNT] += 1
            elif file_row.get_state() == FileRowHelper.UNKNOWN_STATE:
                self.summary_dict[self.UNKNONW_COUNT] += 1
        self.summary_dict[self.FILE_COUNT] += 1

    def aggregate_consistency_data(self):
        """
        Creates summary file
        """
        self.logger.info("Aggregate storage consistency summary data\n summary is: {0}".format(self.summary_dict))
        summary_header = 'Storage Consistency - Summary Values'
        with open(self.summary_path, 'wb') as summary_file: 
            summary_file.write(report_utils.obj_to_pretty_str(dict(self.summary_dict),
                                                              summary_header))
